// Three retained games. Original game numbers stay fixed.
function b12Held(s,e,k){if(e.action===k)s[k]=e.kind==='buttonDown'}
function b12Metal(x,y,w,h,c='#506878'){rect(x+4,y+5,w,h,'#142d3a',5);rect(x,y,w,h,c,5);line(x+4,y+3,x+w-4,y+3,'#bdcbd1',1);for(let a of[x+6,x+w-6])circle(a,y+6,2,'#d9d8c5')}
function b12ScoreFire(s){return s.fires.reduce((n,f)=>n+1-f.hp,0)*100/3}
defs.push({id:'ballistic_firehose',number:12,title:'モブくん消防ホース',tag:'MIDNIGHT FIRE BRIGADE',seconds:15,max:100,control:'stick',buttons:[{id:'water',label:'WATER'}],controlHint:'上下でノズル角度。WATERで放水。',description:'反動と重力を読み、3階の炎の根元へ放水。',rules:'スティック上下で角度を調整し、WATERを長押し。<br>水は山なりに飛びます。炎の根元を狙おう。',scoring:'3つの窓の鎮火率 × 各33.3点。全窓を消して100点。放水は合計8秒。水がなくなった瞬間に終了。',init(){return{a:-.65,water:false,supply:8,emit:0,drops:[],fires:[105,185,265].map(y=>({y,hp:1})),used:0,finished:false}},input(s,e){if(!s.finished)b12Held(s,e,'water')},cancel(s){s.water=false},update(s,dt){
  if(s.finished)return;
  if(s.supply<=0){s.supply=0;s.water=false;s.drops=[];s.finished=true;score=b12ScoreFire(s);end('WATER EMPTY');return}
  // Stop simulation at the actual empty-supply instant, even for a long frame.
  const step=s.water?Math.min(dt,s.supply):dt;
  let d=direction();s.a=clamp(s.a+d.y*1.12*step,-1.18,-.12);
  if(s.water){
    s.a=clamp(s.a-.065*step,-1.18,-.12);
    s.supply=Math.max(0,s.supply-step);s.used=Math.min(8,s.used+step);s.emit-=step;
    while(s.emit<=0){s.emit+=1/60;s.drops.push({x:84,y:338,vx:480*Math.cos(s.a),vy:480*Math.sin(s.a),life:0})}
  }else s.emit=0;
  for(let p of s.drops){
    let ox=p.x,oy=p.y;p.vy+=260*step;p.x+=p.vx*step;p.y+=p.vy*step;p.life+=step;
    if(ox<292&&p.x>=292){
      let yy=lerp(oy,p.y,(292-ox)/(p.x-ox));
      for(let f of s.fires){let offset=Math.abs(yy-f.y);if(offset<30&&f.hp>0){let old=f.hp;f.hp=Math.max(0,f.hp-(offset<12?.016:.006));if(old>0&&f.hp===0)fx(316,f.y,'鎮火!','#9af5ef')}}
      p.dead=true;
    }
  }
  s.drops=s.drops.filter(p=>!p.dead&&p.y<415&&p.life<2);score=b12ScoreFire(s);
  if(score>99.99||s.supply===0){s.finished=true;s.water=false;s.drops=[];end(score>99.99?'ALL FIRES OUT':'WATER EMPTY')}
},draw(s){rect(0,0,400,440,grad(0,0,0,440,[[0,'#111e3a'],[1,'#536075']]));circle(72,48,24,'#ffe6b1');for(let i=0;i<8;i++){rect(i*59-20,160-(i%3)*25,48,200,'#25364b');for(let j=0;j<5;j++)rect(i*59-10,177+j*28-(i%3)*25,8,12,'#bca37455')}poly([[271,36],[382,48],[382,372],[271,365]],'#36464c');poly([[382,48],[400,27],[400,358],[382,372]],'#202f3b');for(let y=40;y<368;y+=19)line(276,y,378,y+10,'#596168',1);s.fires.forEach((f,i)=>{ellipse(326,f.y-22,42,38,'#131f2b99');rect(293,f.y-48,65,53,'#101a24',2);poly([[293,f.y-48],[301,f.y-42],[301,f.y],[293,f.y+5]],'#77828a');rect(288,f.y+3,77,9,'#92989b',2);if(f.hp>0){for(let j=0;j<6;j++){let x=303+j*9,h=(24+Math.sin(time*9+j*2)*9)*Math.sqrt(f.hp);poly([[x-8,f.y],[x-9,f.y-h*.6],[x+Math.sin(time*7+j)*5,f.y-h-13],[x+7,f.y-h*.45],[x+9,f.y]],j%2?'#ffb846':'#f36c39');poly([[x-4,f.y],[x,f.y-h*.65],[x+4,f.y]],'#ffe6a2')}}else{rect(304,f.y-40,42,34,'#537e81');text('SAFE',325,f.y-23,10,'#c7fff3')}rect(299,f.y+17,54,4,'#16232c');rect(299,f.y+17,54*(1-f.hp),4,'#81e5eb')});rect(0,386,400,54,'#303c49');for(let x=0;x<400;x+=65)line(x,389,x-22,440,'#5c6470');ellipse(77,400,60,12,'#101d31aa');ctx.beginPath();ctx.moveTo(0,419);ctx.bezierCurveTo(140,455,27,360,73,353);ctx.strokeStyle='#bb694f';ctx.lineWidth=12;ctx.stroke();mob(63,363,69,s.water?-.04:0);line(71,348,84,338,'#dfb883',10);line(78,342,84+Math.cos(s.a)*29,338+Math.sin(s.a)*29,'#a9bdc3',12);line(81,340,84+Math.cos(s.a)*30,338+Math.sin(s.a)*30,'#e3eeee',3);s.drops.forEach(p=>line(p.x,p.y,p.x-p.vx*.014,p.y-p.vy*.014,'#a3edff',3));text('MIDNIGHT / FIRE BRIGADE',18,23,10,'#c5d6df','left');text(`残水 ${Math.max(0,s.supply).toFixed(1)}s`,76,427,12,'#bce9ef')},summary:s=>`鎮火 ${s.fires.filter(f=>f.hp===0).length}/3窓・総鎮火率 ${Math.round(b12ScoreFire(s))}%`});
// One timing decision per throw; the curve is automatic and always clears the pillar.
function b13Meter(s){let t=s.phase%2;return t<=1?t:2-t}
function b13Points(v){let e=Math.abs(v-.5);return e<=.08+1e-9?100/3:e<=.19+1e-9?20:e<=.31+1e-9?10:0}
function b13Label(p){return p===100/3?'33.3':String(p)}
function b13Path(t,side,endX){let u=1-t;return{x:u*u*u*239+3*u*u*t*(side>0?340:35)+3*u*t*t*(side>0?340:50)+t*t*t*endX,y:u*u*u*362+3*u*u*t*318+3*u*t*t*110+t*t*t*75}}
function b13Launch(s){
  if(s.finished||s.disc||s.wait>0||s.round>=3)return;
  const value=b13Meter(s),points=b13Points(value),sign=value<.5?-1:1;
  const endX=200+(points===100/3?(value-.5)*175:points===20?sign*41:points===10?sign*65:sign*99);
  s.disc={t:0,x:239,y:362,endX,points,side:s.round%2?-1:1,trail:[]};
  s.thrown++;s.feedback='';beep(490,.04);
}
function b13Resolve(s,p,timeout=false){
  if(s.finished||s.round>=3)return;
  s.points.push(p);s.round++;s.disc=null;s.wait=.55;s.aimLeft=3;
  s.phase=(s.round*.31)%2;
  s.feedback=timeout?'TIME UP +0':p===100/3?'IN! +33.3':p===20?'FRAME +20':p===10?'CURVED +10':'MISS +0';
  s.feedbackColor=p===100/3?'#eaffcf':p?'#ffe3a1':'#ffd3b7';
  score=s.points.reduce((a,b)=>a+b,0);fx(200,112,s.feedback,s.feedbackColor);
  if(s.round>=3){s.finished=true;end('THREE THROWS')}
}
defs.push({
  id:'curved_disc',number:13,title:'モブくんカーブディスク',tag:'SEASIDE DISC ARENA',seconds:0,rounds:3,max:100,
  control:'buttons',buttons:[{id:'throw',label:'THROW'}],
  controlHint:'針が緑の帯に来たらTHROWを1回。',
  description:'緑の帯で投げ、柱をかわして奥のネットへ3投。',
  rules:'動く針が緑の帯に入ったらTHROWを1回。<br>ディスクは自動でカーブします。1投の待ち時間は3秒。',
  scoring:'緑の帯33.3点／すぐ隣20点／外側10点／離れすぎ・時間切れ0点。3投で100点。',
  init(){return{phase:0,round:0,thrown:0,disc:null,points:[],wait:0,aimLeft:3,throwHeld:false,finished:false,feedback:'',feedbackColor:'#eaffcf'}},
  input(s,e){
    if(e.action!=='throw')return;
    if(e.kind==='buttonUp'||e.kind==='buttonCancel'){s.throwHeld=false;return}
    if(e.kind==='buttonDown'&&!s.throwHeld){s.throwHeld=true;b13Launch(s)}
  },
  cancel(s){s.throwHeld=false},
  update(s,dt){
    if(s.finished)return;
    if(s.disc){
      let p=s.disc;p.t=Math.min(1,p.t+dt/1.3);let at=b13Path(p.t,p.side,p.endX);p.x=at.x;p.y=at.y;
      p.trail.push([p.x,p.y]);if(p.trail.length>75)p.trail.shift();
      if(p.t>=1)b13Resolve(s,p.points);
      return;
    }
    if(s.wait>0){s.wait=Math.max(0,s.wait-dt);return}
    let step=Math.min(dt,s.aimLeft);s.phase+=step*.65;s.aimLeft=Math.max(0,s.aimLeft-step);
    if(s.aimLeft===0)b13Resolve(s,0,true);
  },
  draw(s){
    rect(0,0,400,440,grad(0,0,0,440,[[0,'#95cfc9'],[.3,'#dce8cd'],[.31,'#3e9dac'],[.48,'#287c96'],[.49,'#e5c697'],[1,'#b59065']]));
    circle(326,43,26,'#fff2cc');for(let i=0;i<6;i++)line(0,139+i*10,400,141+i*10,'#ace2de55');
    poly([[95,118],[305,118],[386,393],[14,393]],'#cee1c7');
    for(let i=0;i<9;i++)line(95-i*10,118+i*34,305+i*10,118+i*34,'#9dc4ae');
    line(96,118,16,393,'#fff3ce',3);line(304,118,384,393,'#fff3ce',3);
    poly([[163,49],[240,49],[234,91],[168,91]],'#577b7e');
    for(let i=0;i<8;i++)line(167+i*10,52,172+i*8,89,'#c0e8dc',1);
    for(let y=55;y<91;y+=8)line(165,y,238,y,'#d0ebe0',1);
    line(158,48,158,103,'#f5ead7',5);line(242,48,242,103,'#f5ead7',5);line(158,48,242,48,'#f5ead7',5);
    // The dotted automatic route explains the curve without another control.
    if(!s.disc&&!s.finished){for(let i=1;i<20;i++){let p=b13Path(i/20,s.round%2?-1:1,200);ellipse(p.x,p.y,2.5,1.6,'#fff7d599')}}
    ellipse(200,273,39,12,'#436d6955');poly([[174,159],[218,159],[226,268],[174,268]],'#8c9c95');
    poly([[218,159],[235,170],[235,258],[226,268]],'#657e7b');poly([[174,159],[187,149],[235,159],[218,170]],'#c5cec0');
    for(let y=186;y<267;y+=24)line(176,y,225,y,'#c3cbbc',2);
    for(let i=0;i<3;i++){rect(126+i*52,16,44,22,i<s.points.length?'#376e69':'#ffffffa6',6);text(i<s.points.length?b13Label(s.points[i]):i+1,148+i*52,27,11,i<s.points.length?'#fff0bf':'#447a72')}
    if(s.disc){
      let p=s.disc;p.trail.forEach((v,i)=>{if(i%4===0)ellipse(v[0],v[1],4,1.5,'#ecfff08a')});
      ellipse(p.x+5,p.y+14,13,4,'#376e6955');ellipse(p.x,p.y,13,5,'#e7ad55');ellipse(p.x,p.y-2,13,4,'#fff3ac');line(p.x-5,p.y-3,p.x+5,p.y-1,'#c57a4f',2);
    }
    // Timing meter stays clear of both the pillar and the selected MOB.
    rect(45,289,310,65,'#315e59ed',10);
    text(s.disc?'CURVING…':s.wait>0?s.feedback:'緑の帯で THROW',200,303,12,s.wait>0?s.feedbackColor:'#f2f5d6');
    const mx=68,mw=264,my=326;
    rect(mx,my-8,mw,16,'#a08d78',5);
    rect(mx+mw*.19,my-8,mw*.62,16,'#bea875',4);
    rect(mx+mw*.31,my-8,mw*.38,16,'#e1c681',3);
    rect(mx+mw*.42,my-9,mw*.16,18,'#8be5a4',3);
    line(200,my-8,200,my+8,'#e8ffcd',1);
    let px=mx+b13Meter(s)*mw;
    line(px,my-12,px,my+12,'#fffce6',3);poly([[px-5,my-15],[px+5,my-15],[px,my-9]],'#fffce6');
    text('33.3',200,344,9,'#d2fac5');text('20',mx+mw*.355,344,9,'#f3dfb5');text('20',mx+mw*.645,344,9,'#f3dfb5');
    ellipse(200,415,41,9,'#5e5c4666');mob(200,386,65,s.disc?-.12:0);
    line(219,376,238,365,'#f0cb99',9);if(!s.disc)ellipse(239,362,13,5,'#ffe6a3');
    text(`THROW ${Math.min(3,s.round+1)} / 3${s.disc?' · FLIGHT':s.wait>0?' · NEXT':` · ${s.aimLeft.toFixed(1)}s`}`,200,431,11,'#f8e5c7');
  },
  summary:s=>`各投 ${s.points.map(b13Label).join(' / ')}点・ネット内 ${s.points.filter(n=>n===100/3).length}/3`
});
function b16Target(){return[37,31,29,37,49,56,54,45]}
function b16Score(s){let base=0,remain=0;for(let i=0;i<8;i++){base+=68-s.target[i]-2;remain+=s.cracked[i]?68-s.target[i]-2:Math.max(0,Math.abs(s.r[i]-s.target[i])-2)}return clamp((base-remain)/base)*100}
defs.push({id:'lathe_pottery',number:16,title:'モブくんろくろの名人',tag:'KILN HOUSE CERAMICS',seconds:15,max:100,control:'stick',buttons:[{id:'press',label:'PRESS'}],controlHint:'上下で手の高さ。PRESSでゆっくり押す。',description:'回る粘土を両手で押し、完成の輪郭へ花瓶を成形。',rules:'上下で指の高さ、PRESS長押しで粘土を押す。<br>金色の完成線へ合わせよう。周りの高さも一緒に変形します。',scoring:'8段の半径誤差を初期から改善した割合×100。全段が目標±2以内で100点。細くしすぎた段は0点。',init(){return{r:Array(8).fill(68),target:b16Target(),cracked:Array(8).fill(false),h:0,press:false,work:0}},input(s,e){b12Held(s,e,'press')},cancel(s){s.press=false},update(s,dt){let d=direction();s.h=clamp(s.h+d.y*3.8*dt,0,7);if(s.press){s.work+=dt;for(let i=0;i<8;i++){let weight=Math.max(0,1-Math.abs(i-s.h)/1.3);s.r[i]=Math.max(12,s.r[i]-weight*20*dt);if(s.r[i]<20)s.cracked[i]=true}}score=b16Score(s);if(score>=99.99)end('MASTERPIECE')},draw(s){rect(0,0,400,440,grad(0,0,0,440,[[0,'#dfd5ba'],[1,'#ae9274']]));for(let x=0;x<400;x+=52)line(x,0,x,306,'#c6b99f');rect(28,36,129,147,'#776f59',5);rect(36,44,113,130,'#a3b2a0');line(93,45,93,173,'#eee0bb',5);line(36,103,149,103,'#eee0bb',5);rect(275,59,111,11,'#8b694d');for(let i=0;i<4;i++){let x=290+i*25;ellipse(x,53,9,5,'#ad8c6a');poly([[x-9,53],[x-7,31],[x+5,31],[x+9,53]],i%2?'#9b7357':'#d3b18b');ellipse(x,31,6,3,'#685d50')}rect(0,342,400,98,'#926b51');for(let y=350;y<440;y+=23)line(0,y,400,y-4,'#aa8360');ellipse(215,396,112,20,'#594a3e55');b12Metal(157,351,118,43,'#707d75');ellipse(216,348,101,24,'#5e695f');ellipse(216,340,101,21,'#a5aea0');for(let i=0;i<8;i++){let a=i*TAU/8+time*4;line(216+Math.cos(a)*70,340+Math.sin(a)*15,216+Math.cos(a)*96,340+Math.sin(a)*20,'#d2d4b8',1)}let cx=216,top=140,dy=28;let left=s.r.map((r,i)=>[cx-r,top+i*dy]),right=s.r.map((r,i)=>[cx+r,top+i*dy]).reverse();poly([...left,...right],grad(cx-68,0,cx+68,0,[[0,'#86563b'],[.2,'#c3936a'],[.46,'#dfba89'],[.72,'#b37d54'],[1,'#7a5139']]));for(let i=0;i<8;i++){let y=top+i*dy,r=s.r[i];ellipse(cx,y,r,7,i===0?'#d0a779':'#d2a57422');if(i===0)ellipse(cx,y,r-7,4,'#71513e');line(cx-r+3,y+3,cx+r-3,y+3,s.cracked[i]?'#3a3430':'#a477542a',1);if(s.cracked[i])line(cx-8,y-6,cx+7,y+9,'#493c31',2)}ctx.save();ctx.setLineDash([5,4]);ctx.strokeStyle='#fdf0b1';ctx.lineWidth=2;for(let side of[-1,1]){ctx.beginPath();s.target.forEach((r,i)=>i?ctx.lineTo(cx+side*r,top+i*dy):ctx.moveTo(cx+side*r,top+i*dy));ctx.stroke()}ctx.restore();let y=top+s.h*dy,idx=Math.round(s.h),r=s.r[idx];rect(65,y+64,58,8,'#806044',3);line(74,y+69,74,393,'#665a47',5);line(113,y+69,113,393,'#665a47',5);mob(95,y+35,64,s.press?.04:0);line(111,y+25,cx-r-(s.press?0:10),y,'#e2bb90',8);ellipse(cx-r-(s.press?0:10),y,9,5,'#f3ce9c');line(108,y+45,cx-r-4,y+22,'#b78c64',7);ellipse(cx-r-4,y+22,8,4,'#f3ce9c');if(s.press){for(let i=0;i<6;i++){let t=(time*3+i*.17)%1;ellipse(cx-r-14-t*35,y+t*t*43,3-t*2,2,'#c49167')}}text('KILN HOUSE / HAND THROWN',200,19,10,'#715944');text('金色の輪郭へ',220,112,13,'#725b42');text(`輪郭の改善 ${Math.round(b16Score(s))}%`,217,423,13,'#fae3bf')},summary:s=>`8段の輪郭改善 ${Math.round(b16Score(s))}%・細くしすぎ ${s.cracked.filter(Boolean).length}段`});
