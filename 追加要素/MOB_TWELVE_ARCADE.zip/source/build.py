from pathlib import Path
import json,base64
p=Path(__file__).parent
assets=['data:image/png;base64,'+base64.b64encode((p/f'MOB-{n}-pixel.png').read_bytes()).decode() for n in ['001','004','005']]
s=(p/'shell.html').read_text().replace('/*__ASSETS__*/','const ASSETS='+json.dumps(assets)+';').replace('/*__ENGINE__*/',(p/'engine.js').read_text()).replace('/*__GAMES__*/','\n'.join((p/n).read_text() for n in ['games.js','games_007_011.js','games_012_016.js']))
(p.parent/'MOB_TWELVE_ARCADE.html').write_text(s)
print(len(s.encode()))
