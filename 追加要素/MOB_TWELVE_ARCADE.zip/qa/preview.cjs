const fs=require('fs'),path=require('path');
const {createCanvas,loadImage,GlobalFonts}=require('@napi-rs/canvas');
GlobalFonts.registerFromPath('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc','Noto');
const ROOT=path.resolve(__dirname,'..');
const catalog=JSON.parse(fs.readFileSync(path.join(ROOT,'12ゲーム一覧.json'),'utf8'));
async function montage(games,name){
  const cw=360,ch=457,gap=20,cols=3,rows=Math.ceil(games.length/cols),width=cols*cw+(cols+1)*gap,height=125+rows*ch+45;
  const can=createCanvas(width,height),c=can.getContext('2d');c.fillStyle='#101628';c.fillRect(0,0,width,height);
  c.fillStyle='#ffee68';c.font='800 32px Noto';c.fillText('MOB TWELVE ARCADE / V3',25,49);
  c.fillStyle='#b7c7de';c.font='16px Noto';c.fillText('元の番号を維持 / パンケーキ・ディスクは1ボタン / 終了条件を改善',25,83);
  for(let i=0;i<games.length;i++){
    const g=games[i],x=gap+(i%cols)*(cw+gap),y=115+Math.floor(i/cols)*ch;
    c.fillStyle='#243047';c.beginPath();c.roundRect(x,y,cw,ch-18,14);c.fill();
    const im=await loadImage(path.join(__dirname,g.id+'.png'));c.drawImage(im,x+7,y+7,cw-14,(cw-14)*1.1);
    c.fillStyle='#f5e6b8';c.font='bold 15px Noto';c.fillText(String(g.number).padStart(2,'0')+' '+g.title,x+15,y+405);
    c.fillStyle='#c6d3e7';c.font='12px Noto';c.fillText(g.seconds?g.seconds+'秒 / '+g.max+'点':g.rounds+'ラウンド / '+g.max+'点',x+15,y+427);
  }
  c.fillStyle='#90a0bd';c.font='12px Noto';c.fillText('ゲームのCanvas描画。実ブラウザのスクリーンショットではありません。',25,height-22);
  fs.writeFileSync(path.join(__dirname,name),can.toBuffer('image/png'));
}
(async()=>{await montage(catalog,'12-game-preview.png');await montage(catalog.filter(g=>g.number>6),'6-new-game-preview.png')})().catch(e=>{console.error(e);process.exitCode=1});
