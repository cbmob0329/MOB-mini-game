'use strict';
// Independent integration QA: JavaScript VM + @napi-rs/canvas + an explicit DOM/event stub.
// This is NOT browser/mobile validation. State fixtures are labeled separately from legal-input paths.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const crypto = require('crypto');
const {createCanvas, Image, loadImage, GlobalFonts} = require('@napi-rs/canvas');
const ROOT = path.resolve(__dirname, '..');
const SOURCE = path.join(ROOT, 'source');
const EXPECTED = ['meteor','archery','juice','lock','shield','rally','inertial_docking','pendulum_cargo','pancake_flip_catch','ballistic_firehose','curved_disc','lathe_pottery'];
const NUMBERS = [1,2,3,4,5,6,7,9,10,12,13,16];
const ORIGINAL = EXPECTED.slice(0,6);
const RETIRED = ['drift_parking','plastic_forging','active_flippers','bell_resonance'];
const FILES = ['engine.js','games.js','games_007_011.js','games_012_016.js'];
GlobalFonts.registerFromPath('/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc', 'system-ui');

function environment(source = SOURCE) {
  const canvas = createCanvas(800,880), els = {}, winEvents = {}, docEvents = {};
  class Element {
    constructor(tag = 'div') {
      this.tagName=tag.toUpperCase(); this.style={}; this.hidden=false; this.children=[]; this._html=''; this.textContent=''; this.listeners={};
      this.classList={toggle(){},add(){},remove(){}};
    }
    set id(v){this._id=v;els[v]=this;} get id(){return this._id;}
    set innerHTML(v){
      this._html=v;this.children=[];
      // Stub parses the IDs used by the engine; layout/focus behavior is intentionally not modeled.
      for(const m of v.matchAll(/<(\w+)[^>]*\bid="([^"]+)"[^>]*>/g)){const child=new Element(m[1]);child.id=m[2];this.children.push(child);}
    }
    get innerHTML(){return this._html;}
    appendChild(e){this.children.push(e);return e;}
    querySelectorAll(selector){let result=[];for(const child of this.children){if(selector==='canvas'&&child.tagName==='CANVAS'||selector.startsWith('.')&&(child.className||'').split(' ').includes(selector.slice(1)))result.push(child);result.push(...child.querySelectorAll(selector));}return result;}
    querySelector(selector){return this.querySelectorAll(selector)[0]||new Element(selector);}
    getBoundingClientRect(){return{left:0,top:0,width:400,height:440};}
    getContext(){const ctx=(this.id==='stage'?canvas:(this._canvas||(this._canvas=createCanvas(400,240)))).getContext('2d');if(!ctx._auditWrapped){const original=ctx.drawImage.bind(ctx);ctx.drawImage=(image,...args)=>original(image instanceof Element?(image.id==='stage'?canvas:image._canvas):image,...args);ctx._auditWrapped=true;}return ctx;}
    setPointerCapture(id){this.captured=id;}
    addEventListener(type,fn){(this.listeners[type]||=[]).push(fn);}
    cloneNode(){return new Element(this.tagName);}
  }
  const get=id=>els[id]||(els[id]=Object.assign(new Element(),{id}));
  class WrappedImage extends Image {
    set src(v){super.src=typeof v==='string'&&v.startsWith('data:')?Buffer.from(v.split(',')[1],'base64'):v;}
    get src(){return super.src;}
    cloneNode(){return new Element('img');}
  }
  let seed=0x421337;
  const math=Object.create(Math); math.random=()=>{seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;};
  const sandbox={console,Math:math,Image:WrappedImage,performance:{now:()=>0},requestAnimationFrame(){},
    document:{getElementById:get,createElement:tag=>new Element(tag),addEventListener(type,fn){(docEvents[type]||=[]).push(fn);},body:{style:{}},hidden:false},
    window:{addEventListener(type,fn){(winEvents[type]||=[]).push(fn);}},
    ASSETS:['001','004','005'].map(n=>'data:image/png;base64,'+fs.readFileSync(path.join(SOURCE,`MOB-${n}-pixel.png`)).toString('base64')),
  };
  vm.createContext(sandbox);
  for(const file of FILES)vm.runInContext(fs.readFileSync(path.join(source,file),'utf8'),sandbox,{filename:file});
  vm.runInContext(`const auditOriginalDraw=draw;draw=()=>{};
    const auditEvent=(pointerId=1,x=260,y=220)=>({pointerId,clientX:x,clientY:y,preventDefault(){}});
    function auditInit(id){closeGame();openGame(defs.find(d=>d.id===id));start();last=0;}
    function auditStep(dt=1/120){frame(last+dt*1000);}
    function auditAdvance(seconds){for(let n=0;n<Math.ceil(seconds*120)&&mode==='play';n++)auditStep();}
    function auditTap(action=current.buttons?.[0]?.id){if(action){buttonPress(action,'audit:tap');buttonRelease(action,'audit:tap',false);}else{emit('down');emit('up');}}
    function auditDescriptor(d){return JSON.stringify(Object.fromEntries(Object.entries(d).filter(([k])=>!['no','number','sourceNumber','originalNumber','poster'].includes(k)).map(([k,v])=>[k,typeof v==='function'?v.toString():v])));}
  `,sandbox);
  return{
    run(code){return vm.runInContext(code,sandbox);},canvas,sandbox,els,
    event(type,event={}){for(const fn of winEvents[type]||[])fn({key:'',repeat:false,preventDefault(){},...event});},
    docEvent(type,event={}){for(const fn of docEvents[type]||[])fn(event);},
    async loadImages(){sandbox.auditImages=await Promise.all(['001','004','005'].map(n=>loadImage(path.join(SOURCE,`MOB-${n}-pixel.png`))));sandbox.auditImages.forEach(im=>im.cloneNode=()=>new Element('img'));this.run('images=auditImages');},
  };
}

async function main(){
  const e=environment();await e.loadImages();
  const tests=[];const report={environment:'Node VM + @napi-rs/canvas + DOM/event stubs; not a real browser or mobile device',sourceHashes:Object.fromEntries(FILES.map(n=>[n,crypto.createHash('sha256').update(fs.readFileSync(path.join(SOURCE,n))).digest('hex')])),tests};
  function check(name,fn,category='integration'){try{const details=fn();assert.notStrictEqual(details,false);tests.push({name,category,pass:true,...(details&&typeof details==='object'?{details}:{})});}catch(err){tests.push({name,category,pass:false,error:String(err),stack:err.stack.split('\n').slice(0,5).join('\n')});console.error('FAIL:',name,String(err));}}
  function js(name,code,category){check(name,()=>{assert(e.run(code));},category);}
  function init(id){e.run(`auditInit(${JSON.stringify(id)})`);}

  check('Exactly the twelve retained definitions, in original order',()=>assert.deepStrictEqual(Array.from(e.run('defs.map(d=>d.id)')),EXPECTED));
  js('No retired definitions registered',`defs.every(d=>!${JSON.stringify(RETIRED)}.includes(d.id))`);
  check('Six originals retain all metadata and implementation',()=>{
    const old=environment(path.resolve(ROOT,'../MINI_revision_v2/source'));
    for(const id of ORIGINAL)assert.equal(e.run(`auditDescriptor(defs.find(d=>d.id==='${id}'))`),old.run(`auditDescriptor(defs.find(d=>d.id==='${id}'))`),id);
  },'regression');
  check('Pottery unchanged except source-number metadata',()=>{
    const old=environment(path.resolve(ROOT,'../MINI_revision_v2/source'));
    assert.equal(e.run("auditDescriptor(defs.find(d=>d.id==='lathe_pottery'))"),old.run("auditDescriptor(defs.find(d=>d.id==='lathe_pottery'))"));
  },'regression');

  for(const id of EXPECTED){
    init(id);
    js(`${id}: max score contract`, `current.max===${id==='lock'?10:100}`);
    js(`${id}: ready/start/pause/resume/retry/close`, `(()=>{
      if(mode!=='play'||score!==0||time!==0)return false;
      if(current.buttons)for(const b of current.buttons){buttonPress(b.id,'key:q');buttonPress(b.id,'pointer:2');buttonRelease(b.id,'key:q',false);buttonRelease(b.id,'pointer:2',true);}
      keys.arrowright=true;stick.x=1;pauseGame();let before=JSON.stringify(state),t=time;auditStep(2);
      if(mode!=='paused'||time!==t||JSON.stringify(state)!==before||Object.keys(keys).length||stick.x||stick.y||Object.keys(buttonSources).length)return false;
      $('resume').onclick();if(mode!=='play')return false;
      end('QA RESULT');if(mode!=='result')return false;let result=score;emit('down');if(score!==result)return false;
      $('retry').onclick();if(mode!=='play'||score!==0||time!==0)return false;
      closeGame();return mode==='lobby'&&$('overlay').hidden;
    })()`);
    for(let trial=0;trial<4;trial++){
      init(id);
      check(`${id}: ${['idle','held','repeated-cancel','variable-dt'][trial]} finite terminal`,()=>{
        const r=e.run(`(()=>{
          let frames=0,min=0,max=0;
          if(${trial}===1&&current.buttons)for(const b of current.buttons)buttonPress(b.id,'audit:hold');
          while(mode==='play'&&time<45&&frames<10000){frames++;
            if(${trial}>0){stick.x=Math.sin(frames*.079);stick.y=Math.cos(frames*.047);}
            if(${trial}>1){
              if(current.buttons)for(const b of current.buttons){
                if(frames%19===0){buttonPress(b.id,'audit:repeat');buttonPress(b.id,'audit:repeat');}
                if(frames%19===7)buttonRelease(b.id,'audit:repeat',frames%38===7);
              }else if(frames%19===0){emit('down');emit('down');}else if(frames%19===7)emit(frames%38===7?'cancel':'up');
            }
            if(${trial}===1&&!current.buttons&&frames===1)emit('down');
            auditStep(${trial}===3?[1/30,1/144,.1,1/60][frames%4]:1/120);
            if(!Number.isFinite(score)||score<0||score>current.max+1e-6)throw Error('invalid score '+score);
            min=Math.min(min,score);max=Math.max(max,score);if(frames%240===0)auditOriginalDraw();
          }
          if(mode!=='result')throw Error('unterminated '+JSON.stringify({mode,time,frames}));
          auditOriginalDraw();
          return{score,time,frames,min,max};
        })()`);
        if(trial===0&&EXPECTED.indexOf(id)>=6)assert.equal(r.score,0,'new-game idle score');
        return r;
      },'simulation');
    }
    init(id);check(`${id}: native Canvas render`,()=>{e.run('time=1.25;auditOriginalDraw()');},'render');
  }

  init('meteor');
  js('Input ownership: stick and fire, unrelated pointer, cancellation and mixed sources',`(()=>{
    let pad=$('stick'),button=$('action-fire');pad.onpointerdown(auditEvent(1));button.onpointerdown(auditEvent(2));
    if(!(pid===1&&state.firing&&stick.x>0))return false;
    button.onpointerup(auditEvent(3));if(!state.firing)return false;
    pad.onpointercancel(auditEvent(1));if(stick.x!==0||!state.firing)return false;
    button.onpointercancel(auditEvent(2));if(state.firing)return false;
    button.onpointerdown(auditEvent(4));buttonPress('fire','key:q');button.onpointerup(auditEvent(4));if(!state.firing)return false;
    buttonRelease('fire','key:q',false);return !state.firing;
  })()`);
  for(const id of ['pancake_flip_catch','curved_disc']){
    init(id);
    js(`${id}: exactly one timing button and no stick`, `current.control!=='stick'&&current.buttons.length===1&&current.rounds===3`);
    js(`${id}: round HUD uses three-round count`, `$('timeLabel').textContent==='ROUND'&&$('timer').textContent==='1 / 3'`);
    check(`${id}: held/repeated keyboard routes a single buttonDown`,()=>{
      e.run("auditInput=current.input;auditEvents=[];current.input=(s,event)=>{auditEvents.push(event.kind);auditInput(s,event)}");
      e.event('keydown',{key:' '});e.event('keydown',{key:' ',repeat:true});e.event('keydown',{key:'q'});e.event('keyup',{key:' '});
      assert.equal(e.run("auditEvents.filter(k=>k==='buttonDown').length"),1);
      e.event('keyup',{key:'q'});assert.equal(e.run("auditEvents.filter(k=>k==='buttonUp').length"),1);
      e.run('current.input=auditInput;');
    });
    init(id);check(`${id}: window blur pauses and visibility can pause`,()=>{
      e.event('keydown',{key:' '});e.event('blur');assert.equal(e.run('mode'),'paused');assert.equal(e.run('Object.keys(buttonSources).length'),0);
      e.run("$('resume').onclick()");e.sandbox.document.hidden=true;e.docEvent('visibilitychange');assert.equal(e.run('mode'),'paused');e.sandbox.document.hidden=false;
    });
  }

  // Mechanic-specific tests are inserted below after the final implementation is available.
  if(typeof mechanicTests==='function')mechanicTests({e,init,check,js});

  check('Built HTML exactly matches current shell, assets, engine and all three game modules',()=>{
    const file=path.join(ROOT,'MOB_TWELVE_ARCADE.html');
    const actual=fs.readFileSync(file,'utf8');
    const assets=['001','004','005'].map(n=>'data:image/png;base64,'+fs.readFileSync(path.join(SOURCE,`MOB-${n}-pixel.png`)).toString('base64'));
    const assetLine='const ASSETS=['+assets.map(x=>JSON.stringify(x)).join(', ')+'];';
    const expected=fs.readFileSync(path.join(SOURCE,'shell.html'),'utf8').replace('/*__ASSETS__*/',assetLine).replace('/*__ENGINE__*/',fs.readFileSync(path.join(SOURCE,'engine.js'),'utf8')).replace('/*__GAMES__*/',FILES.slice(1).map(n=>fs.readFileSync(path.join(SOURCE,n),'utf8')).join('\n'));
    assert.equal(actual,expected);
    report.bundle={filename:path.basename(file),bytes:Buffer.byteLength(actual),sha256:crypto.createHash('sha256').update(actual).digest('hex')};
    return report.bundle;
  },'bundle');
  check('Built HTML has no retired game IDs and only the twelve-game entry file remains',()=>{
    const html=fs.readFileSync(path.join(ROOT,'MOB_TWELVE_ARCADE.html'),'utf8');
    for(const id of RETIRED)assert(!html.includes(id),id);
    assert.deepStrictEqual(fs.readdirSync(ROOT).filter(n=>n.endsWith('.html')),['MOB_TWELVE_ARCADE.html']);
    assert(html.includes('TWELVE ARCADE'));assert(!html.includes('SIXTEEN ARCADE'));
    new vm.Script(html.match(/<script>([\s\S]*?)<\/script>/)[1]);
  },'bundle');
  check('Twelve-game JSON catalog matches final definitions and original numbers',()=>{
    const actual=JSON.parse(fs.readFileSync(path.join(ROOT,'12ゲーム一覧.json'),'utf8'));
    const expected=JSON.parse(e.run(`JSON.stringify(defs.map((d,i)=>({number:d.number||i+1,id:d.id,title:d.title,description:d.description,seconds:d.seconds,rounds:d.rounds||(d.seconds?null:10),max:d.max,control:d.control,controlHint:d.controlHint||'',buttons:d.buttons||[],rules:d.rules,scoring:d.scoring})))`));
    assert.deepStrictEqual(actual,expected);return{games:actual.length,numbers:actual.map(d=>d.number)};
  },'bundle');

  // Real boot routine is called only after the gameplay cases so its asynchronous poster pass is isolated.
  e.run('closeGame();boot()');await new Promise(resolve=>setImmediate(resolve));
  check('Final menu has twelve cards with retained source numbers',()=>{
    const cards=e.els.grid.children;assert.equal(cards.length,12);
    const nums=cards.map(card=>Number(card.innerHTML.match(/class="number">(?:No\.\s*)?(\d+)/)?.[1]));
    assert.deepStrictEqual(nums,NUMBERS);
    for(const card of cards)assert(!/\b(?:08|11|14|15) \/ /.test(card.innerHTML));
    return{numbers:nums};
  });
  check('Three-round menu badges',()=>{
    for(const id of ['pancake_flip_catch','curved_disc'])assert(e.els.grid.children[EXPECTED.indexOf(id)].innerHTML.includes('3ラウンド'));
  });
  check('Source files remained stable during this audit',()=>{for(const file of FILES)assert.equal(crypto.createHash('sha256').update(fs.readFileSync(path.join(SOURCE,file))).digest('hex'),report.sourceHashes[file],file);});
  report.summary={total:tests.length,passed:tests.filter(t=>t.pass).length,failed:tests.filter(t=>!t.pass).length};
  fs.writeFileSync(path.join(__dirname,'audit_v3_results.json'),JSON.stringify(report,null,2)+'\n');
  fs.writeFileSync(path.join(__dirname,'audit_v3_report.txt'),`${report.environment}\n${JSON.stringify(report.summary)}\n`+tests.map(t=>`${t.pass?'PASS':'FAIL'} [${t.category}] ${t.name}${t.error?': '+t.error:''}`).join('\n')+'\n');
  console.log(JSON.stringify({environment:report.environment,summary:report.summary,failures:tests.filter(t=>!t.pass)},null,2));
  if(report.summary.failed)process.exitCode=1;
}

if(require.main===module)main().catch(err=>{console.error(err);process.exitCode=1;});
module.exports={environment};

function mechanicTests({e,init,check,js}){
  // Stable scoring under legal, single-action timed throws (no direct score/state mutation).
  for(const [meter,expected,label] of [[.5,100,'perfect'],[.65,60,'frame partial'],[.75,30,'outer partial'],[.9,0,'miss']]){
    init('curved_disc');check(`Disc legal timing: ${label}`,()=>{
      const r=e.run(`(()=>{for(let i=0;i<3600&&mode==='play';i++){if(!state.disc&&state.wait<=0&&Math.abs(b13Meter(state)-${meter})<=.004)auditTap();auditStep();}return{score,time,mode,round:state.round,thrown:state.thrown,points:state.points};})()`);
      assert.equal(r.mode,'result');assert.equal(r.score,expected);assert.equal(r.round,3);assert.equal(r.thrown,3);assert.equal(r.points.length,3);return r;
    },'legal-input');
  }
  init('curved_disc');js('Disc held input only launches once across all rounds',`(()=>{buttonPress('throw','audit:hold');auditAdvance(20);return mode==='result'&&state.thrown===1&&state.round===3&&state.points.length===3;})()`,'legal-input');
  init('curved_disc');js('Disc release/cancel cannot launch, repeated press in flight cannot duplicate',`(()=>{buttonRelease('throw','ghost',true);if(state.disc)return false;auditTap();let n=state.thrown;for(let i=0;i<25;i++){auditTap();auditStep()}return state.thrown===n&&n===1;})()`,'legal-input');
  init('curved_disc');js('Disc round deadline gives zero and finishes all three rounds',`(()=>{auditAdvance(20);return mode==='result'&&score===0&&state.thrown===0&&state.round===3&&state.points.length===3&&time<10.2;})()`,'legal-input');
  init('curved_disc');js('Disc result begins immediately on third resolution without extra wait',`(()=>{state.round=2;state.points=[100/3,100/3];state.disc={t:1-1e-5,x:200,y:76,endX:200,points:100/3,side:1,trail:[]};current.update(state,1/120);return mode==='result'&&score===100&&state.round===3;})()`,'state-fixture');
  init('curved_disc');js('Disc no score drift after result',`(()=>{auditAdvance(20);let value=score,points=JSON.stringify(state.points),t=time;for(let i=0;i<100;i++){auditTap();auditStep(.1);current.update(state,.1)}return score===value&&JSON.stringify(state.points)===points&&time===t;})()`,'state-fixture');

  init('ballistic_firehose');js('Hose zero supply immediately ends without advancing pending hit',`(()=>{
    state.supply=0;state.water=true;state.drops=[{x:291,y:105,vx:480,vy:0,life:0}];current.update(state,1/120);
    return mode==='result'&&score===0&&state.supply===0&&!state.water&&state.finished&&state.drops.length===0&&state.fires[0].hp===1;
  })()`,'state-fixture');
  init('ballistic_firehose');js('Hose fractional supply stops at exact exhaustion before later projectile hit',`(()=>{
    state.supply=.001;state.water=true;state.drops=[{x:291,y:105,vx:480,vy:0,life:0}];current.update(state,.1);
    return mode==='result'&&score===0&&state.supply===0&&state.drops.length===0&&state.fires[0].hp===1;
  })()`,'state-fixture');
  init('ballistic_firehose');js('Hose final score remains unchanged after exhaustion',`(()=>{
    state.supply=.001;state.water=true;current.update(state,.1);let value=score,hp=JSON.stringify(state.fires);
    current.input(state,{kind:'buttonDown',action:'water'});state.drops.push({x:291,y:105,vx:480,vy:0,life:0});current.update(state,2);
    return score===value&&JSON.stringify(state.fires)===hp&&!state.water;
  })()`,'state-fixture');
  for(const limit of [100,36]){
    init('ballistic_firehose');check(`Hose legal aim/water path: ${limit===100?'100':'partial'} points`,()=>{
      const r=e.run(`(()=>{
        const targets=state.fires.map(f=>{let best=0,error=1e9;for(let a=-1.18;a<=-.12;a+=.0005){let t=208/(480*Math.cos(a)),y=338+480*Math.sin(a)*t+130*t*t,err=Math.abs(y-f.y);if(err<error){best=a;error=err}}return best});
        let stopped=false;
        for(let i=0;i<2000&&mode==='play';i++){
          if(score>=${limit})stopped=true;
          const idx=state.fires.findIndex(f=>f.hp>0);
          if(idx<0||stopped){buttonRelease('water','audit:bot',false);stick.y=0;}
          else{const target=targets[idx];stick.y=clamp((target-state.a)*15+.065/1.12,-1,1);if(Math.abs(state.a-target)<.027)buttonPress('water','audit:bot');else buttonRelease('water','audit:bot',false);}
          auditStep();
        }
        return{score,time,mode,supply:state.supply,finished:state.finished};
      })()`);
      assert.equal(r.mode,'result');if(limit===100)assert.equal(r.score,100);else assert(r.score>0&&r.score<100);return r;
    },'legal-input');
  }
  init('inertial_docking');js('Docking has only one stick and no rotation buttons', `current.control==='stick'&&!current.buttons`);
  init('inertial_docking');check('Docking legal single-stick path docks in under two seconds',()=>{
    const r=e.run(`(()=>{for(let i=0;i<240&&mode==='play';i++){let x=294-state.x,y=166-state.y,m=Math.max(1,Math.hypot(x,y));stick.x=x/m;stick.y=y/m;auditStep()}return{mode,time,score,locked:state.locked};})()`);
    assert.equal(r.mode,'result');assert.equal(r.score,100);assert(r.time<2);assert(r.locked);return r;
  },'legal-input');
  init('inertial_docking');js('Docking entering zone ends in the same update at speed, without orientation control',`(()=>{Object.assign(state,{x:268,y:166,vx:180,vy:0,a:Math.PI,active:true});stick.x=1;current.update(state,1/120);return score===100&&mode==='result'&&state.locked&&state.resolved;})()`,'state-fixture');
  init('inertial_docking');js('Docking releases stop quickly',`(()=>{stick.x=1;auditAdvance(.5);stick.x=0;let x=state.x;auditAdvance(.3);return state.x-x<8&&Math.hypot(state.vx,state.vy)<.5;})()`,'legal-input');
  init('inertial_docking');check('Docking legal partial approach yields a finite sub-100 result',()=>{
    const r=e.run(`(()=>{stick.x=1;auditAdvance(.65);stick.x=0;auditAdvance(12);return{mode,time,score};})()`);
    assert.equal(r.mode,'result');assert(r.score>0&&r.score<100);return r;
  },'legal-input');

  for(const [x,label] of [[280,'full overlap'],[250,'partial overlap'],[107,'miss']]){
    init('pendulum_cargo');check(`Cargo legal one-placement path: ${label}`,()=>{
      const r=e.run(`(()=>{let settled=0;for(let i=0;i<1440&&mode==='play';i++){
        if(!state.committed){stick.x=clamp((${x}-state.x)*.055,-1,1);if(Math.abs(state.x-${x})<.08&&Math.abs(state.v)<.3)settled+=1/120;else settled=0;if(settled>.6)auditTap('lower')}
        auditStep();
      }return{score,time,mode,landed:state.landed,resolved:state.resolved,last:state.last};})()`);
      assert.equal(r.mode,'result');assert(r.landed&&r.resolved);if(x===280)assert.equal(r.score,100);else if(x===250)assert(r.score>0&&r.score<100);else assert.equal(r.score,0);assert(r.time<6);return r;
    },'legal-input');
  }
  init('pendulum_cargo');js('Cargo has one LOWER action and no lift/retry',`current.buttons.length===1&&current.buttons[0].id==='lower'&&!/持ち上げ|2回|再挑戦/.test(current.rules+' '+current.scoring)`);
  init('pendulum_cargo');js('Cargo lowering is irreversible on release, cancel, repeat and stick input',`(()=>{
    auditTap('lower');let x=state.x,len=state.len;
    current.input(state,{kind:'buttonCancel',action:'lower'});current.input(state,{kind:'buttonDown',action:'lift'});stick.x=1;
    for(let i=0;i<30;i++){auditTap('lower');auditStep()}
    return state.committed&&state.lower&&state.len>len&&state.x===x;
  })()`,'legal-input');
  init('pendulum_cargo');js('Cargo landing ends in the first contact update',`(()=>{Object.assign(state,{x:280,len:249.8,a:0,av:0,committed:true,lower:true});current.update(state,1/120);return state.landed&&state.resolved&&mode==='result'&&score===100&&Math.abs(cargoPose(state).y+cargoBottom(state)-351)<1e-8;})()`,'state-fixture');
  init('pendulum_cargo');js('Cargo cannot re-place after landing and result remains fixed',`(()=>{auditTap('lower');auditAdvance(2);let result=score,pose=JSON.stringify(state.placed);current.input(state,{kind:'buttonDown',action:'lift'});auditTap('lower');current.update(state,10);return mode==='result'&&score===result&&JSON.stringify(state.placed)===pose&&state.landed;})()`,'state-fixture');
  init('pendulum_cargo');js('Cargo pause freezes committed descent and resume completes same placement',`(()=>{
    auditTap('lower');auditAdvance(.2);pauseGame();let len=state.len;auditStep(2);if(state.len!==len||!state.committed)return false;$('resume').onclick();auditAdvance(2);return mode==='result'&&state.landed;
  })()`,'legal-input');

  for(const [meter,label] of [[.5,'perfect'],[.2,'partial']]){
    init('pancake_flip_catch');check(`Pancake legal timing: ${label}`,()=>{
      const r=e.run(`(()=>{for(let i=0;i<2000&&mode==='play';i++){if(state.phase==='ready'&&Math.abs(pancakeMeter(state)-${meter})<.004)auditTap();auditStep()}return{mode,time,score,round:state.round,results:state.results};})()`);
      assert.equal(r.mode,'result');assert.equal(r.round,3);assert.equal(r.results.length,3);if(meter===.5)assert.equal(r.score,100);else assert(r.score>0&&r.score<100);return r;
    },'legal-input');
  }
  init('pancake_flip_catch');js('Pancake idle deadlines resolve three zero-point attempts',`(()=>{auditAdvance(20);return mode==='result'&&score===0&&state.round===3&&state.results.length===3&&state.results.every(n=>n===0);})()`,'legal-input');
  init('pancake_flip_catch');js('Pancake repeated presses during flight cannot duplicate awards',`(()=>{auditTap();for(let i=0;i<80;i++){auditTap();auditStep()}return state.round===0&&state.results.length===0;})()`,'legal-input');
  init('pancake_flip_catch');js('Pancake third catch ends without feedback delay',`(()=>{state.round=2;state.results=[100/3,100/3];state.points=200/3;state.pending=100/3;state.phase='flying';state.flight=.799;current.update(state,1/120);return state.round===3&&state.resolved&&mode==='result'&&score===100;})()`,'state-fixture');
}
