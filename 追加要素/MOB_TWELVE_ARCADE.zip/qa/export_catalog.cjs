const fs=require('fs'),path=require('path'),{env}=require('./test_six.cjs');
const e=env(),ROOT=path.resolve(__dirname,'..');
for(const n of ['games_007_011.js','games_012_016.js'])e.run(fs.readFileSync(path.join(ROOT,'source',n),'utf8'));
const catalog=e.run(`defs.map((d,i)=>({number:d.number||i+1,id:d.id,title:d.title,description:d.description,seconds:d.seconds,rounds:d.rounds||(!d.seconds?10:null),max:d.max,control:d.control,controlHint:d.controlHint||'',buttons:d.buttons||[],rules:d.rules,scoring:d.scoring}))`);
fs.writeFileSync(path.join(ROOT,'12ゲーム一覧.json'),JSON.stringify(catalog,null,2));
fs.writeFileSync(path.join(ROOT,'12ゲーム一覧.txt'),'MOB TWELVE ARCADE / V3\n元のゲーム番号を維持した12作\n\n'+catalog.map(d=>`${String(d.number).padStart(2,'0')} ${d.title}\n${d.description}\n${d.seconds?d.seconds+'秒':d.rounds+'ラウンド'} / ${d.max}点満点\n操作：${d.rules.replace(/<br>/g,' ')}\n採点：${d.scoring}\n`).join('\n'));
console.log(JSON.stringify(catalog.map(d=>({number:d.number,id:d.id})),null,2));
