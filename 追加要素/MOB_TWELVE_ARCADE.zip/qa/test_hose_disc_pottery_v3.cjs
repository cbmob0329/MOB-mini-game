'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const {createCanvas,loadImage}=require('@napi-rs/canvas');
const root=__dirname+'/../source/',src=fs.readFileSync(root+'games_012_016.js','utf8');
const canvas=createCanvas(800,880),ctx=canvas.getContext('2d');ctx.scale(2,2);let avatar=null;
const e={console,Math,ctx,defs:[],TAU:Math.PI*2,time:0,score:0,mode:'play',dir:{x:0,y:0},ends:[],
  clamp:(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),lerp:(a,b,t)=>a+(b-a)*t,dist:(a,b,c,d)=>Math.hypot(a-c,b-d),beep(){},fx(){},
  end(reason){if(e.mode==='play'){e.mode='result';e.ends.push(reason)}},direction(){return e.dir},
  mob(x,y,size=55,a=0){if(!avatar)return;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.imageSmoothingEnabled=false;let k=size/Math.max(avatar.width,avatar.height);ctx.drawImage(avatar,-avatar.width*k/2,-avatar.height*k/2,avatar.width*k,avatar.height*k);ctx.restore()}};
vm.createContext(e);const eng=fs.readFileSync(root+'engine.js','utf8');vm.runInContext(eng.slice(eng.indexOf('function rect'),eng.indexOf('let images')),e);vm.runInContext(src,e);
const game=id=>e.defs.find(g=>g.id===id),hose=game('ballistic_firehose'),disc=game('curved_disc'),pottery=game('lathe_pottery');
function reset(g){e.time=e.score=0;e.mode='play';e.dir={x:0,y:0};e.ends=[];return g.init()}
function tick(g,s,dt=1/120){e.time+=dt;g.update(s,dt);assert(Number.isFinite(e.score));assert(e.score>=0&&e.score<=100+1e-8)}
function btn(g,s,id,on){g.input(s,{kind:on?'buttonDown':'buttonUp',action:id})}
function run(g,bot,max=20){let s=reset(g),n=0;while(n++<max*120&&e.mode==='play'){bot?.(s,g,n);tick(g,s)}return{s,score:e.score,time:e.time,reason:e.ends[0]}}
function firebot(s,g){let f=s.fires.find(f=>f.hp>0);if(!f)return;let best=0,error=1e9;for(let a=-1.18;a<=-.12;a+=.0005){let t=208/(480*Math.cos(a)),y=338+480*Math.sin(a)*t+130*t*t,er=Math.abs(y-f.y);if(er<error){best=a;error=er}}e.dir.y=e.clamp((best-s.a)*15+.065/1.12,-1,1);btn(g,s,'water',Math.abs(s.a-best)<.027)}
function discbot(target){return(s,g)=>{if(!s.disc&&s.wait<=0&&Math.abs(e.b13Meter(s)-target)<.005){btn(g,s,'throw',true);btn(g,s,'throw',false)}}}
function potterybot(){let amounts=[31,37,39,31,19,12,14,23],A=amounts.map((v,i)=>Array.from({length:9},(_,j)=>j===8?v:j===i?1:Math.abs(j-i)===1?3/13:0));for(let i=0;i<8;i++){let q=A[i][i];for(let j=i;j<9;j++)A[i][j]/=q;for(let k=0;k<8;k++)if(k!==i){let m=A[k][i];for(let j=i;j<9;j++)A[k][j]-=m*A[i][j]}}let plan=A.map(r=>r[8]/20),idx=0,held=0;return(s,g)=>{if(idx>=8){btn(g,s,'press',false);e.dir.y=0;return}e.dir.y=e.clamp((idx-s.h)*18,-1,1);let press=Math.abs(idx-s.h)<.008;if(press){held+=1/120;if(held>=plan[idx]){held=0;idx++;press=false}}btn(g,s,'press',press)}}
async function main(){
  let checks=0;const ok=(condition,label)=>{assert(condition,label);checks++};let report={environment:'Node VM + canvas, not browser testing'};
  ok(JSON.stringify(e.defs.map(g=>[g.id,g.number]))===JSON.stringify([['ballistic_firehose',12],['curved_disc',13],['lathe_pottery',16]]),'retained ids and numbers only');
  const potteryOriginal=src.slice(src.indexOf('function b16Target')).replace("{id:'lathe_pottery',number:16,","{id:'lathe_pottery',");
  ok(crypto.createHash('sha256').update(potteryOriginal).digest('hex')==='5328b41a340b7ac1b0a3197fbb952ec0254eab3e5e00f73351aa802216c05fe1','pottery byte-identical except number');
  for(const g of [hose,pottery]){const r=run(g,null,15);ok(r.score===0,g.id+' idle 0')}
  let r=run(hose,(s,g)=>btn(g,s,'water',true));ok(r.s.supply===0,'hose exact zero');ok(r.reason==='WATER EMPTY','hose empty ends');ok(r.time<8.02,'hose no delay after eight seconds');ok(r.s.drops.length===0,'hose drops cleared');ok(!r.s.water,'hose controls released');report.hoseExhaustion={score:r.score,time:r.time,supply:r.s.supply};
  const frozen=JSON.stringify(r.s),frozenScore=e.score;for(let i=0;i<100;i++){btn(hose,r.s,'water',true);tick(hose,r.s,.1)}ok(JSON.stringify(r.s)===frozen&&e.score===frozenScore&&e.ends.length===1,'hose result remains frozen under update/input');
  let s=reset(hose);s.supply=0;s.drops=[{x:291,y:105,vx:480,vy:0,life:0}];tick(hose,s,.1);ok(s.fires[0].hp===1&&e.score===0,'already-empty water cannot score flying drop');
  s=reset(hose);s.supply=.001;s.water=true;s.drops=[{x:291,y:105,vx:480,vy:0,life:0}];tick(hose,s,.1);ok(s.supply===0&&s.fires[0].hp===1&&e.score===0,'large frame stops physics at depletion');
  s=reset(hose);s.supply=.001;s.water=true;s.drops=[{x:291.9,y:105,vx:480,vy:0,life:0}];tick(hose,s,.1);ok(s.fires[0].hp<1&&e.score>0,'pre-depletion contact still earns points');
  s=reset(hose);s.water=true;tick(hose,s,.6);hose.cancel(s);let supply=s.supply;for(let i=0;i<30;i++)tick(hose,s,.1);ok(s.supply===supply&&!s.water,'cancel stops water, no recharge');
  r=run(hose,firebot);ok(r.score>99.99&&r.reason==='ALL FIRES OUT','hose legal perfect 100 and all-out ending');report.hosePerfect={score:r.score,time:r.time,supply:r.s.supply};
  ok(disc.control==='buttons'&&disc.buttons.length===1&&disc.buttons[0].id==='throw','disc single button only');ok(disc.seconds===0&&disc.rounds===3,'disc three rounds without flight cutoff');
  for(const [v,p] of [[.42,100/3],[.58,100/3],[.31,20],[.69,20],[.19,10],[.81,10],[0,0],[1,0]])ok(e.b13Points(v)===p,'disc scoring band edge '+v);
  for(const side of [-1,1])for(const endX of [101,135,159,186,200,214,241,265,299])for(let t=0;t<1;t+=.001){let p=e.b13Path(t,side,endX);if(p.y>=146&&p.y<=281)assert(p.x<161||p.x>248,'automatic curve avoids pillar including disc radius')}
  checks++;r=run(disc,null);ok(r.score===0&&r.s.round===3&&r.reason==='THREE THROWS'&&r.time<10.2,'idle resolves three zero-point deadlines');report.discIdle={score:r.score,time:r.time};
  for(const [target,total] of [[.5,100],[.65,60],[.75,30],[.9,0]]){r=run(disc,discbot(target));ok(Math.abs(r.score-total)<1e-8,'legal disc total '+total);ok(r.s.thrown===3&&r.s.points.length===3&&r.s.round===3,'exactly three throws/awards');ok(r.time<15,'disc bounded completion');report['disc'+total]={score:r.score,time:r.time}}
  s=reset(disc);btn(disc,s,'throw',true);for(let i=0;i<230;i++){btn(disc,s,'throw',true);tick(disc,s)}ok(s.thrown===1&&s.round===1,'held/repeated downs cannot launch second');btn(disc,s,'throw',false);btn(disc,s,'throw',true);ok(s.thrown===2,'release allows second');disc.cancel(s);ok(!s.throwHeld,'cancel clears throw latch');
  r=run(disc,(s,g)=>{btn(g,s,'throw',true);btn(g,s,'throw',false)});ok(r.s.thrown===3&&r.s.points.length===3&&r.s.round===3&&e.ends.length===1,'rapid repeated taps cannot skip/duplicate');
  let before=JSON.stringify(r.s),beforeScore=e.score;for(let i=0;i<10;i++){btn(disc,r.s,'throw',true);btn(disc,r.s,'throw',false);tick(disc,r.s,.2)}ok(r.s.thrown===3&&r.s.points.length===3&&e.score===beforeScore,'disc score frozen after third');
  r=run(pottery,potterybot(),15);ok(r.score>99.99,'unchanged pottery perfect path');report.potteryPerfect={score:r.score,time:r.time};
  if(process.argv.includes('--render')){avatar=await loadImage(root+'MOB-001-pixel.png');for(const g of [hose,disc,pottery]){s=reset(g);if(g===disc){for(let i=0;i<83;i++)tick(g,s);g.draw(s);fs.writeFileSync('/tmp/disc_v3_ready.png',canvas.toBuffer('image/png'));btn(g,s,'throw',true);for(let i=0;i<55;i++)tick(g,s)}g.draw(s);fs.writeFileSync('/tmp/'+g.id+'_v3.png',canvas.toBuffer('image/png'))}}
  report.checks=checks;report.result='PASS';console.log(JSON.stringify(report,null,2));
}
main().catch(err=>{console.error(err);process.exitCode=1});
