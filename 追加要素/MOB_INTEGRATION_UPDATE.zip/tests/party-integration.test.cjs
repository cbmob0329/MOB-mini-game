const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const core=require('../party-core.js');
function engine(){
  const element={addEventListener(){},removeEventListener(){},classList:{add(){},remove(){},contains(){return false;}},querySelector(){return null;},querySelectorAll(){return [];},style:{setProperty(){}},setAttribute(){},removeAttribute(){}};
  const document={addEventListener(){},getElementById(){return element;},querySelector(){return element;},querySelectorAll(){return [];},documentElement:element,body:element};
  const pending=[];
  const window={MobPartyCore:core,MobPartyLeague:require('../party-league.js'),MobPartyLeagueUI:{create(api){window.leagueAdapter=api;return {stop(){}};}},MobPartyUI:{create(){return {};}},MobPartyGames:{create(){return {};}},addEventListener(){}};
  const context=vm.createContext({window,document,console,Math,performance:{now:()=>0},setTimeout:fn=>{pending.push(fn);return pending.length;},clearTimeout(){},setInterval:()=>0,clearInterval(){},requestAnimationFrame:()=>0,cancelAnimationFrame(){},Image:class{},URL,localStorage:{getItem(){return null;},setItem(){}}});
  let source=fs.readFileSync(require.resolve('../game.js'),'utf8');
  source=source.replace(/renderHome\(\);\r?\n\}\)\(\);/,`window.__test={GAMES,MODES,PLAYERS,points1990,show1990Final,startTestRecord(i){activeGameIndex=i;gameSessionActive=true;},getHTML(){return screen.innerHTML;},hoppingHasSupport,masteryPoints,scoreRuleForGame,activeGameIndices,performancePoints,rankRecords,applyPoints,applyConfiguredBattle,participants,freshState,simulateOneCpu,teamTotals,setState(s){state=s},getState(){return state}};})();`);
  vm.runInContext(source,context);return {...window.__test,league:window.leagueAdapter,flush(){while(pending.length)pending.shift()();}};
}

test('league adapter supports 40 entrants and freely assigned eight humans',()=>{
  const e=engine(),players=Array.from({length:40},(_,i)=>({id:i<8?'p'+(i+1):'leagueCpu'+i,name:'Player '+i,cpu:i>=8,characterRank:'A'}));
  const teams=Array.from({length:20},(_,i)=>({id:'L'+i,name:'Team '+i,members:[players[i].id,players[39-i].id]}));
  [teams[0].members[1],teams[7].members[0]]=[teams[7].members[0],teams[0].members[1]];
  e.league.configure(players,teams);
  assert.equal(e.participants().length,40);assert.equal(e.participants().filter(p=>!p.cpu).length,8);
  assert.deepEqual(Array.from(e.MODES.configured.teams.L0),['p1','p8']);
  assert.deepEqual(Array.from(e.MODES.configured.teams.L7),['leagueCpu39','leagueCpu32']);
  assert.equal(e.getState().competitionStarted,true);
});

test('new league adapter supports eighty entrants, twenty humans and twenty solo finalists',()=>{
  const e=engine(),players=Array.from({length:80},(_,i)=>({id:i<20?'p'+(i+1):'variantCpu'+i,name:'Player '+i,cpu:i>=20,characterRank:'A'}));
  const crews=Array.from({length:20},(_,i)=>({id:'C'+i,name:'CREW '+i,members:players.slice(i*4,i*4+4).map(p=>p.id)}));
  e.league.configure(players,crews,{mode:'crew',title:'Crew League'});assert.equal(e.participants().length,80);assert.equal(e.participants().filter(p=>!p.cpu).length,20);
  players.forEach(p=>p.cpu=true);e.league.configure(players,crews,{mode:'crew',title:'Crew League'});
  let result;e.league.run('reaction',crews,{round:1,phase:'qualifier'},points=>result=points);e.flush();assert.equal(Object.keys(result).length,80);assert.ok(Object.values(result).every(n=>Number.isFinite(n)&&n>=0&&n<=100));
  const singles=players.map((p,i)=>({id:'K'+i,name:p.name,members:[p.id]}));e.league.configure(players,singles,{mode:'king',title:'MOB KING League'});
  players[0].name+='（PB2リーグ 1位）';e.league.updatePlayers(players);e.league.run('reaction',singles.slice(0,20),{round:1,phase:'final'},points=>result=points);e.flush();assert.equal(Object.keys(result).length,20);assert.match(e.participants()[0].name,/PB2リーグ 1位/);
});

test('CPU tag heats return four finite scores and team-shared results',()=>{
  const e=engine(),players=Array.from({length:40},(_,i)=>({id:'leagueCpu'+i,name:'CPU '+i,cpu:true,characterRank:'A'}));
  const teams=Array.from({length:20},(_,i)=>({id:'L'+i,name:'Team '+i,members:players.slice(i*2,i*2+2).map(p=>p.id)}));
  e.league.configure(players,teams);
  for(const key of require('../party-league.js').TAG){
    let result=null;e.league.run(key,teams.slice(0,2),{round:3},scores=>result=scores);e.flush();
    assert.equal(Object.keys(result).length,4,key);
    for(const t of teams.slice(0,2)){assert.equal(result[t.members[0]],result[t.members[1]],key);assert.ok(result[t.members[0]]>=0&&result[t.members[0]]<=100,key);}
    if(key==='summonMaster')assert.equal(Object.values(result).reduce((a,b)=>a+b,0),200);
  }
});
test('175 games have records; new games score directly on a 100-point scale',()=>{
  const e=engine(),state=e.freshState();assert.equal(e.GAMES.length,175);
  for(const g of e.GAMES)assert.ok(state.records[g.key],g.key);
  for(const key of ['galaxyArcadeMob','archeryArcadeMob','shieldArcadeMob','dockingArcadeMob','cargoArcadeMob','pancakeArcadeMob','firehoseArcadeMob','discArcadeMob','juiceArcadeMob','rallyArcadeMob','potteryArcadeMob','bananaBoatMob','warpedWallMob','santaClausMob','colorBridgeParty','treasureEscapeParty','treasureRuneParty','treasureDuoParty']){const i=e.GAMES.findIndex(g=>g.key===key);assert.ok(i>=0);assert.equal(e.performancePoints(i,80),80);}
});
test('fast CPU death game keeps the exact elimination distribution',()=>{
  const e=engine(),players=Array.from({length:40},(_,i)=>({id:'leagueCpu'+i,name:'CPU '+i,cpu:true,characterRank:'A'}));
  const teams=Array.from({length:20},(_,i)=>({id:'L'+i,name:'Team '+i,members:players.slice(i*2,i*2+2).map(p=>p.id)}));
  e.league.configure(players,teams);let result;e.league.run('deathGameChallenge',teams,{round:9},scores=>result=scores);e.flush();
  const counts={};Object.values(result).forEach(n=>counts[n]=(counts[n]||0)+1);
  assert.deepEqual(counts,{10:10,30:15,50:10,65:2,80:2,100:1});
});
test('8-team cup has 32 participants; representatives alone score and omitted players stay unchanged',()=>{
  const e=engine();e.applyConfiguredBattle({type:'team',rule:'score',teamCount:8,teamSize:4,assignments:Array.from({length:8},(_,i)=>({players:i?0:4,cpus:i?4:0}))});
  assert.equal(e.participants().length,32);assert.equal(new Set(e.participants().map(p=>p.id)).size,32);
  const state=e.getState(),ids=Object.values(e.MODES.configured.teams).flatMap(team=>team.slice(0,2));
  state.partyRepresentatives=ids;
  const i=e.GAMES.findIndex(g=>g.key==='colorBridgeParty');ids.forEach(id=>state.records.colorBridgeParty[id]=80);
  const ranked=e.rankRecords(i);assert.equal(ranked.length,16);e.applyPoints(i,ranked);
  assert.ok(Object.values(e.teamTotals()).every(n=>n===160));assert.equal(state.total.p3,0);assert.equal(state.total.p4,0);
});
test('10 teams of 2 produce 20 distinct participants',()=>{
  const e=engine();e.applyConfiguredBattle({type:'team',rule:'score',teamCount:10,teamSize:2,assignments:Array.from({length:10},(_,i)=>({players:i?0:2,cpus:i?2:0}))});
  assert.equal(e.participants().length,20);assert.equal(Object.keys(e.MODES.configured.teams).length,10);assert.ok(e.participants().every(Boolean));
});
test('rank-based CPU record generation yields finite records and scores for every game',()=>{
  const e=engine();const p=e.PLAYERS.find(p=>p.cpu);p.characterRank='SS';
  for(let i=0;i<e.GAMES.length;i++){e.simulateOneCpu(i,p);const raw=e.getState().records[e.GAMES[i].key][p.id],points=e.performancePoints(i,raw);assert.ok(Number.isFinite(raw),e.GAMES[i].key);assert.ok(Number.isFinite(points)&&points>=0&&points<=100,e.GAMES[i].key);}
});

test('removed boxing is absent from records, catalog and selection pools; later games keep their legacy IDs',()=>{
  const e=engine();assert.ok(!e.GAMES.some(g=>g.key==='boxing3DMob'));
  assert.ok(!('boxing3DMob' in e.freshState().records));assert.ok(!e.GAMES.some(g=>g.key==='hockey3DMob'));assert.ok(!('hockey3DMob' in e.freshState().records));
  assert.equal(e.activeGameIndices().length,147);
  const active=e.activeGameIndices().map(i=>e.GAMES[i].key);
  for(const key of ['killLeaderMob','mobSpeedRacer','mineCartMob','mobCount','feint','giantHammer3DMob'])assert.ok(!active.includes(key),key);
  assert.equal(e.GAMES.find(g=>g.key==='punchMachine3DMob').legacy,167);
  assert.equal(e.GAMES.find(g=>g.key==='treasureEscapeParty').legacy,181);
});

test('mastery scoring preserves full marks but never rounds a near miss into 100',()=>{
  const {masteryPoints:score}=engine();
  for(const target of [990,105,.995]){
    assert.equal(score(0,target),0);assert.equal(score(target,target),100);
    assert.equal(score(target*2,target),100);assert.ok(score(target-.00001,target)<100);
    let previous=0;for(let i=0;i<=100;i++){const points=score(target*i/100,target);assert.ok(points>=previous&&points<=100);previous=points;}
  }
  assert.ok(score(833,990,1.8)<80);assert.ok(score(100,105,1.6)<100);
});

// Evaluate the actual scoring expressions used by each playable implementation.
test('retired game numbers are excluded everywhere including newly removed 025 are unavailable',()=>{
  const e=engine(),numbers=e.activeGameIndices().map(i=>e.GAMES[i].no);
  for(const n of [18,19,25,39,42,48,50,51,53,55,59,60,63,65,67,68,70,72,78,147,159,160])assert.ok(!numbers.includes(n),String(n));
  assert.ok(numbers.includes(17));assert.ok(!e.league.pool().includes('treasureDuoParty'));
});
test('walking off a hopping platform releases grounded state; a platform below cannot hold a player in midair',()=>{
  const {hoppingHasSupport:support}=engine(),platforms=[{x:100,y:28,h:12,w:78}];
  assert.equal(support(platforms,100,40),true);assert.equal(support(platforms,147,40),true);
  assert.equal(support(platforms,149,40),false);assert.equal(support(platforms,100,80),false);
});
test('requested score boosts preserve zero and cap full marks',()=>{
  const e=engine(),score=(key,v)=>e.performancePoints(e.GAMES.findIndex(g=>g.key===key),v);
  assert.equal(score('overlapMaster',64),80);assert.equal(score('overlapMaster',0),0);
  assert.equal(score('heroMaybe',60),69);assert.equal(score('heroMaybe',100),100);
  assert.equal(score('giantMob',12),50);assert.equal(score('giantMob',24),100);
  assert.equal(score('breakdance',20),20);assert.equal(score('breakdance',40),40);
});
test('catcher awards four points per figure and change detection rewards faster answers',()=>{
  for(const [gotCount,expected] of [[0,0],[1,4],[24,96],[25,100],[33,100]])assert.equal(gameScore('Catcher',/function scoreNow\(\)\s*\{\s*return ([^;]+);/,{gotCount}),expected);
  const score=t=>gameScore('ChangeMob',/sc=(clamp\(Math\.floor[^;]+);/,{t,mistakes:0});
  assert.equal(score(1000),100);assert.equal(score(4000),70);assert.equal(score(7000),40);assert.equal(score(12000),5);
});
test('brake rewards close stops while keeping crashes and distant stops at zero',()=>{
  const e=engine(),index=e.GAMES.findIndex(g=>g.key==='brake');
  for(const [gap,expected] of [[0,100],[.5,100],[.6,99],[3,95],[6,85],[10,70],[20,30],[30,0],[999,0]])assert.equal(e.performancePoints(index,gap),expected,`gap ${gap}`);
  let previous=100;for(let tenth=0;tenth<=300;tenth++){const score=e.performancePoints(index,tenth/10);assert.ok(score<=previous&&score>=0);previous=score;}
});
function gameScore(name,pattern,variables){
  const source=fs.readFileSync(require.resolve('../game.js'),'utf8');
  const start=source.indexOf('async function start'+name+'('),end=source.indexOf('\nasync function ',start+1);
  const match=source.slice(start,end).match(pattern);assert.ok(match,name);
  return vm.runInNewContext(match[1],{...variables,Math,clamp:(v,a,b)=>Math.max(a,Math.min(b,v)),masteryPoints:engine().masteryPoints});
}
test('a spare cannot award full marks',()=>{
  const bowling=(knocked,shot)=>gameScore('Bowling3DMob',/const score=([^;]+);/,{knocked,shot});
  assert.equal(bowling(10,1),100);assert.equal(bowling(10,2),85);assert.equal(bowling(9,2),81);

});
test('climbing full marks require fast completion without wrong-side inputs',()=>{
  const score=(index,sec,mistakes)=>gameScore('BuildingClimb3DMob',/score=(index>=10[^;]+);/,{index,sec,mistakes});
  assert.equal(score(10,6,0),100);assert.ok(score(10,7,0)<100);assert.ok(score(10,6,1)<100);assert.ok(score(9,5,0)<70);
});
test('shot-put perfect distance is reachable at multiple frame rates but not with partial charge',()=>{
  function distance(charge,angle,dt){let y=1.35,z=.15,vy=Math.sin(angle*Math.PI/180)*(8.5+charge*10.8),vz=-Math.cos(angle*Math.PI/180)*(8.5+charge*10.8);while(y>.25){vy-=9.8*dt;y+=vy*dt;z+=vz*dt;}return (-z-1)*2.8;}
  for(const dt of [1/120,1/60,.025]){
    const best=Math.max(...Array.from({length:25},(_,i)=>{const angle=43.4+i*.05;return gameScore('ShotPut3DMob',/const score=([^;]+);/,{distance:distance(1,angle,dt),charge:1,angle});}));assert.equal(best,100);
    assert.ok(gameScore('ShotPut3DMob',/const score=([^;]+);/,{distance:distance(.8,44,dt),charge:.8,angle:44})<80);
  }
});

test('stack awards 75 points for 15 dolls and full marks for 20',()=>{const e=engine(),i=e.GAMES.findIndex(g=>g.key==='stack');assert.equal(e.performancePoints(i,15),75);assert.equal(e.performancePoints(i,20),100);});

test('change detection deducts fifteen points per mistake while allowing recovery',()=>{
  const score=mistakes=>gameScore('ChangeMob',/sc=(clamp\(Math\.floor[^;]+);/,{t:1000,mistakes});
  assert.equal(score(0),100);assert.equal(score(1),85);assert.equal(score(2),70);assert.equal(score(3),55);
});

test('1990 world final uses the shared 100-point score and replay/other-game navigation',()=>{
  for(const rank of [1,10,40]){
    const e=engine(),state=e.freshState(),p={id:'p1',name:'Test',img:'icon/01.png'},index=e.GAMES.findIndex(g=>g.key==='breakdance');
    state.freePlay=true;state.records.breakdance[p.id]=e.points1990(12);e.setState(state);e.startTestRecord(index);
    e.show1990Final(p,0,12,rank);
    const html=e.getHTML();assert.ok(html.includes('record-score100-v204">'+e.points1990(12)+'<small>/100 pt</small>'));
    assert.ok(html.includes('1990を12周'));assert.ok(html.includes('世界順位 '+rank+'位'));
    for(const id of ['soloReplay','soloOther','soloHome'])assert.ok(html.includes('id="'+id+'"'));
  }
});

test('earned point games keep 69 earned points as 69 score and cap at 100',()=>{
  const e=engine();for(const key of ['cardShop','breakdance']){const i=e.GAMES.findIndex(g=>g.key===key);for(let n=0;n<=100;n++)assert.equal(e.performancePoints(i,n),n,key);assert.equal(e.performancePoints(i,180),100);}
  for(const [laps,points] of [[0,0],[1,6],[8,50],[12,75],[15,94],[16,100],[20,100]])assert.equal(e.points1990(laps),points);
});

test('shooting and mole scores receive a modest reduction with reachable caps',()=>{
  const e=engine();
  for(const [key,raw,expected] of [['littleMobShot',170,94],['littleMobShot',180,100],['dontHitMob',14,50],['dontHitMob',27,96],['dontHitMob',28,100],['dontHitMob',40,100]]){
    const i=e.GAMES.findIndex(g=>g.key===key);
    assert.equal(e.performancePoints(i,raw),expected,key);
    assert.equal(e.performancePoints(i,0),0,key);
  }
});

test('open electric course uses the reduced time scale consistently with its guide',()=>{
  const e=engine(),i=e.GAMES.findIndex(g=>g.key==='electricMaze');
  for(const [ms,score] of [[3000,100],[4000,100],[8000,75],[12000,50],[20000,0],[25000,0]])assert.equal(e.performancePoints(i,ms),score);
  assert.match(e.scoreRuleForGame(i),/4秒以下=100点・20秒以上=0点/);
});

test('league event practice games are in the active solo catalog but not random league draws',()=>{
  const e=engine();for(const key of ['minorityMob','focusBombMob']){
    const i=e.GAMES.findIndex(g=>g.key===key);assert.ok(e.activeGameIndices().includes(i));assert.ok(!e.league.pool().includes(key));
    assert.equal(e.performancePoints(i,80),80);assert.equal(e.performancePoints(i,0),0);
  }
});

test('lock preserves ten raw points and converts only tournament points',()=>{const e=engine(),i=e.GAMES.findIndex(g=>g.key==='lockArcadeMob');assert.equal(e.performancePoints(i,0),0);assert.equal(e.performancePoints(i,8),80);assert.equal(e.performancePoints(i,10),100);const p=e.PLAYERS.find(p=>p.cpu);e.simulateOneCpu(i,p);assert.ok(e.getState().records.lockArcadeMob[p.id]<=10);});
