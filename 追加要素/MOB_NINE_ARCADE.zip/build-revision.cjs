const fs=require('fs'),path=require('path');
const root=__dirname,portable=fs.existsSync(path.join(root,'source')),source=path.join(root,portable?'source':'arcade/source'),out=portable?root:path.join(root,'deliverables');fs.mkdirSync(out,{recursive:true});
const read=n=>fs.readFileSync(path.join(source,n),'utf8');
const assets='const ASSETS='+JSON.stringify(['001','004','005'].map(n=>'data:image/png;base64,'+fs.readFileSync(path.join(source,`MOB-${n}-pixel.png`)).toString('base64')))+';';
const engine=read('engine.js');
const responsive=`
/* Fit stage after reserving HUD, readable details and 44px controls. */
.machine{height:calc(100dvh - 8px);max-height:780px;overflow:hidden;display:flex;flex-direction:column}.gamehead,.hud,.controls,.details{flex-shrink:0}.gamehead{min-height:52px}.close,.pause{min-width:44px;min-height:44px}.stage{flex:1;min-height:0;width:calc(100% - 20px);display:flex;align-items:center;justify-content:center}.stage #stage{width:auto;height:100%;max-width:100%;aspect-ratio:400/440;object-fit:contain}.controls{height:105px}.details{font-size:10px;line-height:1.45;padding:4px 14px 8px;color:#c3cee4}.veil{background:#0a122c;padding:12px}.veil h3{font-size:19px}.veil p{font-size:11px;line-height:1.45;margin:7px 0}.veil .primary{min-height:44px;padding:12px}.result{font-size:42px}body{touch-action:manipulation;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none}.embedded .top,.embedded main,.embedded #close{display:none}.embedded .overlay{padding:0;background:#11182a}.embedded .machine{height:100dvh;max-height:none;border-radius:0}.embedded .gamehead{padding:5px 12px;min-height:36px}.embedded .hud{padding-bottom:4px}.embedded .metric{padding:5px 10px}.embedded .controls{height:96px}.embedded .stage{min-height:0}.embedded .details{max-height:48px} 
`;
function shell(games,tail,title){return read('shell.html').replace('/*__ASSETS__*/',assets).replace('/*__ENGINE__*/',engine).replace('/*__GAMES__*/',games).replace('boot();',tail).replace('</style>',responsive+'</style>').replaceAll('TWELVE ARCADE',title)}
const g=read('games.js'),b=read('games_012_016.js');
const approved=g.slice(g.indexOf('function citrus'),g.indexOf("defs.push({id:'lock'"))+g.slice(g.indexOf("defs.push({id:'rally'"))+b.slice(b.indexOf('function b12Held'),b.indexOf('function b12ScoreFire'))+b.slice(b.indexOf('function b16Target'));
const bridge=`
defs.forEach(d=>{d.title={juice:'モブくんのピッタリジュース',rally:'モブくんラリー',lathe_pottery:'モブくんろくろの名人'}[d.id];if(d.id==='lathe_pottery')d.seconds=10});
document.body.classList.add('embedded');
const embeddedGame=new URLSearchParams(location.search).get('game');
const chosen=defs.find(d=>d.id===embeddedGame);let embeddedFinished=false,embeddedStarted=false;
const originalEnd=end;end=function(reason){if(mode!=='play'||embeddedFinished)return;originalEnd(reason);embeddedFinished=true;parent.postMessage({type:'mob-arcade-result',game:current.id,score,note:current.summary?current.summary(state):reason},'*')};
window.addEventListener('message',async e=>{if(e.source!==parent||e.data?.type!=='mob-arcade-start'||embeddedStarted||!chosen)return;embeddedStarted=true;if(e.data.image){const im=new Image();im.src=e.data.image;try{await im.decode();images[0]=im;selected=0}catch{}}start()});
if(chosen){openGame(chosen);$('veil').innerHTML='<div><h3>READY</h3></div>';parent.postMessage({type:'mob-arcade-ready',game:chosen.id},'*');requestAnimationFrame(frame)}
`;
fs.writeFileSync(path.join(out,'party-approved-arcade.html'),shell(approved,bridge,'APPROVED ARCADE'));
const all=[g,read('games_007_011.js'),b,read('revision.js')].join('\n');
// Keep the approved choices until the real-project browser integration checks have passed.
const verified=process.argv.includes('--verified');
const tail=verified?`for(let i=defs.length-1;i>=0;i--)if(['juice','rally','lathe_pottery'].includes(defs[i].id))defs.splice(i,1);boot();`:`defs.forEach(d=>{if(['juice','rally','lathe_pottery'].includes(d.id))d.description='【本体動作確認待ち】'+d.description});boot();`;
let test=shell(all,tail,verified?'NINE ARCADE':'TWELVE ARCADE');
if(verified)test=test.replace('12の遊びを、気軽に。','9のテストを、気軽に。').replace('他の11種目','他の8種目').replace('収録番号：01–07 / 09 / 10 / 12 / 13 / 16（元の番号を維持）','収録番号：01 / 02 / 04 / 05 / 07 / 09 / 10 / 12 / 13（03・06・16は本体導入済み）');
fs.writeFileSync(path.join(out,verified?'MOB_NINE_ARCADE.html':'MOB_TWELVE_ARCADE_PENDING.html'),test);
fs.mkdirSync(path.join(out,'source'),{recursive:true});if(!portable)for(const name of ['engine.js','games.js','games_007_011.js','games_012_016.js','revision.js','shell.html',...['001','004','005'].map(n=>`MOB-${n}-pixel.png`)])fs.copyFileSync(path.join(source,name),path.join(out,'source',name));
console.log('Built',verified?'verified 9':'pending 12','and approved-only integration');
