// Retained games 007, 009 and 010: one clear goal and immediate resolution.
function b7panel(label,sub,c='#a6dce9'){text(label,200,25,12,c);text(sub,200,418,12,c)}

// A responsive one-stick ship. The faint coast is visual, never a braking puzzle.
function dockingScore(s){
  if(!s.active)return 0;
  if(s.locked)return 100;
  const startDistance=Math.hypot(75-294,325-166);
  return Math.min(99,99*clamp(1-Math.hypot(s.x-294,s.y-166)/startDistance));
}
defs.push({
  id:'inertial_docking',number:7,title:'宇宙ドッキング',tag:'ORBITAL APPROACH',seconds:12,max:100,
  control:'stick',controlHint:'スティックで移動・離すとすぐ止まる',
  description:'スティックで小艇を動かし、緑の接続エリアに入れよう。',
  rules:'スティックで小艇を動かし、緑の接続エリアに入れよう。',
  scoring:'緑のエリアに入ると即100点。時間切れは接続口への近さで0〜99点。動かさないと0点。',
  init(){return{x:75,y:325,vx:0,vy:0,a:0,active:false,locked:false,resolved:false,thrustX:0,thrustY:0}},
  input(){},
  cancel(s){s.thrustX=s.thrustY=0;if(!s.resolved)s.vx=s.vy=0},
  update(s,dt){
    if(s.resolved)return;
    const d=direction(),moving=Math.hypot(d.x,d.y)>.03;
    if(moving)s.active=true;
    s.thrustX=moving?d.x:0;s.thrustY=moving?d.y:0;
    const blend=1-Math.exp(-(moving?19:27)*dt);
    s.vx=lerp(s.vx,s.thrustX*180,blend);s.vy=lerp(s.vy,s.thrustY*180,blend);
    if(!moving&&Math.hypot(s.vx,s.vy)<.5)s.vx=s.vy=0;
    s.x=clamp(s.x+s.vx*dt,28,306);s.y=clamp(s.y+s.vy*dt,52,386);
    if(s.active&&s.x>=269&&s.x<=311&&Math.abs(s.y-166)<=29){
      s.x=294;s.y=166;s.vx=s.vy=s.thrustX=s.thrustY=0;s.locked=s.resolved=true;
      score=100;end('DOCKED');return;
    }
    score=dockingScore(s);
  },
  timeout(s){s.resolved=true;s.vx=s.vy=s.thrustX=s.thrustY=0;score=dockingScore(s);end('APPROACH COMPLETE')},
  draw(s){
    rect(0,0,400,440,grad(0,0,400,440,[[0,'#070e24'],[1,'#24315a']]));
    for(let i=0;i<68;i++)circle((i*97)%400,(i*59)%420,i%7===0?1.4:.65,'#bccfe7');
    circle(-34,471,170,grad(0,300,100,440,[[0,'#7ad5e4'],[.2,'#2671ac'],[1,'#183566']]));ring(-34,471,174,'#94e5fa88',3);
    for(let i=0;i<4;i++)ellipse(20+i*22,357+i*17,36,7,'#c4eff033',.3);
    rect(351,57,16,241,'#687a92');
    for(let y of[62,233]){rect(307,y,90,47,'#204873',3);for(let x=313;x<397;x+=14)line(x,y+4,x,y+43,'#79a7c4',1);line(310,y+23,397,y+23,'#6ba9d8')}
    poly([[344,104],[382,124],[397,166],[378,209],[339,216],[320,185],[320,139]],'#d1dae4');
    poly([[344,104],[350,152],[320,185],[320,139]],'#8da3b8');rect(317,146,15,40,'#172b43',3);rect(310,150,10,32,'#9cffbc',2);
    for(let x=185;x<263;x+=22)poly([[x,161],[x+7,166],[x,171]],'#86dcca88');
    text(s.locked?'接続完了':'船型を重ねる',276,120,14,'#baffd8');
    if(!s.resolved&&Math.hypot(s.thrustX,s.thrustY)>.1){
      const a=Math.atan2(-s.thrustY,-s.thrustX),cx=s.x+Math.cos(a)*18,cy=s.y+Math.sin(a)*18;
      poly([[cx-Math.sin(a)*5,cy+Math.cos(a)*5],[s.x+Math.cos(a)*(37+Math.sin(time*70)*4),s.y+Math.sin(a)*(37+Math.sin(time*70)*4)],[cx+Math.sin(a)*5,cy-Math.cos(a)*5]],'#8ce1ff');
    }
    ctx.save();ctx.translate(s.x,s.y);
    ellipse(0,12,31,13,'#00000055');poly([[-25,-20],[-5,-12],[23,-8],[31,0],[23,8],[-5,12],[-25,20],[-18,0]],'#e1e8e9');
    poly([[-23,19],[22,8],[27,2],[-3,4]],'#758baf');rect(-19,-15,11,30,'#7189a4',3);ellipse(0,0,14,11,'#314f71');mob(0,0,26);line(4,-10,14,-5,'#c4faff',2);ctx.restore();
    b7panel('KEPLER STATION / DOCK 07','輪郭を合わせ、離して静止で確定');
  },
  summary:s=>s.locked?'接続成功！ 緑のエリアに入って100点。':s.active?`接続口まで${Math.round(Math.hypot(s.x-294,s.y-166))}px。近さで採点。`:'小艇を動かしていないため0点。'
});

// Position first, then LOWER commits to one uninterrupted descent.
function cargoPose(s){return s.placed||{x:s.x+Math.sin(s.a)*s.len,y:83+Math.cos(s.a)*s.len,v:s.v+Math.cos(s.a)*s.len*s.av}}
function cargoBottom(s){
  return Math.max(...[[-38,-20],[-29,-28],[47,-28],[47,12],[38,18],[-38,18]].map(([x,y])=>x*Math.sin(s.a)+y*Math.cos(s.a)));
}
function cargoFootprint(s,p){
  const base=[[-38,18],[38,18],[47,12]].map(([x,y])=>p.x+x*Math.cos(s.a)-y*Math.sin(s.a));
  return{left:Math.min(...base),right:Math.max(...base)};
}
function cargoScore(s,p){
  const{left,right}=cargoFootprint(s,p);
  const overlap=Math.max(0,Math.min(right,337)-Math.max(left,230));
  return 100*clamp(overlap/(right-left));
}
defs.push({
  id:'pendulum_cargo',number:9,title:'吊り荷ピタッ',tag:'HARBOR GANTRY',seconds:12,max:100,
  control:'stick',controlHint:'左右で位置を合わせ、LOWERを1回',buttons:[{id:'lower',label:'LOWER ↓'}],
  description:'左右で吊り荷を緑の台座に合わせ、LOWERで降ろそう。',
  rules:'左右で吊り荷を緑の台座に合わせ、LOWERを1回押して降ろそう。',
  scoring:'着地した瞬間に終了。荷物の底が台座に重なった割合×100点。全部載ると100点。降ろさないと0点。',
  init(){return{x:107,v:0,len:128,a:0,av:0,active:false,committed:false,lower:false,landed:false,resolved:false,last:0,placed:null}},
  input(s,e){
    if(s.resolved||s.committed)return;
    if(e.action==='lower'&&e.kind==='buttonDown'){s.active=true;s.committed=s.lower=true;s.v=0;beep(410,.05)}
  },
  cancel(s){if(!s.committed)s.v=0},
  update(s,dt){
    if(s.resolved||dt<=0)return;
    let accel=0;
    if(!s.committed){
      const d=direction(),target=Math.abs(d.x)>.03?d.x*145:0;
      if(target)s.active=true;
      const old=s.v;s.v=lerp(s.v,target,1-Math.exp(-13*dt));accel=(s.v-old)/dt;
      s.x=clamp(s.x+s.v*dt,48,352);
      if((s.x===48&&s.v<0)||(s.x===352&&s.v>0))s.v=0;
    }
    const lowering=s.committed?143:0;
    s.len+=lowering*dt;
    // Damped sway makes the hanging load feel physical while remaining readable.
    s.av+=(-520/s.len*Math.sin(s.a)-accel/s.len*.30-(3.6+2*lowering/s.len)*s.av)*dt;
    s.a=clamp(s.a+s.av*dt,-.24,.24);
    let p=cargoPose(s);
    if(s.committed&&p.y+cargoBottom(s)>=351){
      s.len=(351-cargoBottom(s)-83)/Math.cos(s.a);p=cargoPose(s);
      s.last=cargoScore(s,p);s.placed={x:p.x,y:351-cargoBottom(s),v:0};
      s.v=s.av=0;s.lower=false;s.landed=s.resolved=true;score=s.last;
      end(s.last>=99.999?'CARGO PLACED':'LANDING COMPLETE');return;
    }
    score=0;
  },
  timeout(s){s.resolved=true;s.lower=false;s.v=s.av=0;score=s.landed?s.last:0;end('TIME UP')},
  draw(s){
    rect(0,0,400,440,grad(0,0,0,440,[[0,'#bbc8ce'],[.58,'#e2d8c6'],[.59,'#4a8294'],[1,'#285769']]));
    for(let i=0;i<13;i++)line((i*61+time*12)%450-30,280+i*8,(i*61+time*12)%450+13,280+i*8,'#b8d3cd44',2);
    for(let x of[23,365]){poly([[x,55],[x+13,55],[x+8,373],[x-5,373]],'#426777');line(x+2,71,x+6,370,'#80a2a4',3)}
    rect(18,61,366,20,'#718e90',3);rect(26,81,346,7,'#233f55');for(let x=27;x<370;x+=24)line(x,63,x+14,78,'#bdd0bd',2);
    rect(s.x-26,78,52,13,'#dbaf63',3);circle(s.x-18,89,5,'#273c46');circle(s.x+18,89,5,'#273c46');rect(s.x-20,34,39,31,'#416276',4);rect(s.x-17,37,33,25,'#add8d9',3);mob(s.x,49,27);
    const p=cargoPose(s);
    line(s.x-13,88,p.x-22*Math.cos(s.a),p.y-21-22*Math.sin(s.a),'#243c49',2);line(s.x+13,88,p.x+22*Math.cos(s.a),p.y-21+22*Math.sin(s.a),'#243c49',2);
    rect(0,351,400,89,'#76837f');poly([[230,351],[337,351],[352,365],[217,365]],'#b6dfb9');rect(217,365,135,18,'#536b72');
    poly([[230,351],[337,351],[345,359],[222,359]],'#7ad9a0');line(230,351,337,351,'#d2ffe1',2);
    text('ここに載せる',284,390,13,'#e7fff0');
    ellipse(p.x,351,38,5,'#18344366');
    if(!s.committed){
      for(let y=p.y+32;y<337;y+=13)line(p.x,y,p.x,y+5,'#edf6d77a',1.5);
      const footprint=cargoFootprint(s,p);line(footprint.left,338,footprint.right,338,'#fff1bb',3);text('↑ 荷物の幅',(footprint.left+footprint.right)/2,324,11,'#fff8d2');
    }
    ctx.save();ctx.translate(p.x,p.y);ctx.rotate(s.a);rect(-38,-20,76,38,'#b95c49',3);
    poly([[38,-20],[47,-28],[47,12],[38,18]],'#7b3c39');poly([[-38,-20],[-29,-28],[47,-28],[38,-20]],'#da9070');
    for(let x=-30;x<37;x+=10)line(x,-16,x,14,'#e19b77',2);rect(-15,-11,30,18,'#dfb486',1);text('MOB',0,-2,10,'#793d35');ctx.restore();
    b7panel('PORT 09 / CARGO CONTROL',s.landed?`着地 · ${Math.round(s.last)}点`:s.committed?'自動で降下中':'左右で位置合わせ → LOWERを1回','#213e50');
  },
  summary:s=>s.landed?`台座に重なった底の割合：${Math.round(s.last)}%。着地した瞬間の位置で採点。`:'荷物を着地させていないため0点。'
});

// One timing button. The flip and catch are automatic, with three scored attempts.
function pancakeMeter(s){const p=(.08+s.clock*.70)%2;return p<=1?p:2-p}
function pancakeAward(s){const error=Math.abs(pancakeMeter(s)-.5);return (100/3)*clamp(1-Math.max(0,error-.12)/.38)}
function pancakeResolve(s,points,tapped){
  if(s.resolved)return;
  s.points+=points;s.results.push(points);s.round++;score=Math.min(100,s.points);
  s.lastLabel=!tapped?'時間切れ · 0点':points>=100/3-1e-6?'PERFECT!':points<.01?'0点':`+${Math.round(points)}点`;
  if(s.round===3){s.resolved=true;s.phase='done';s.flash=0;end('THREE PANCAKES');return}
  s.phase='ready';s.clock=0;s.flash=.7;
}
defs.push({
  id:'pancake_flip_catch',number:10,title:'パンケーキ返し',tag:'COPPER PAN KITCHEN',seconds:0,rounds:3,max:100,
  control:'buttons',controlHint:'緑に来たらFLIPを1回',buttons:[{id:'flip',label:'FLIP ↑'}],
  description:'メーターの針が緑に来たらFLIPを押し、3枚返そう。',
  rules:'メーターの針が緑に来たらFLIPを押し、3枚返そう。',
  scoring:'緑で1枚33⅓点、3枚で100点。緑から離れるほど点数が少なくなる。1枚3秒、押さない回は0点。',
  init(){return{pan:200,round:0,flips:0,clock:0,phase:'ready',flight:0,points:0,pending:0,results:[],resolved:false,flash:0,lastLabel:'',cake:{x:200,y:303,a:0}}},
  input(s,e){
    if(s.resolved||s.phase!=='ready'||e.action!=='flip'||e.kind!=='buttonDown')return;
    s.pending=pancakeAward(s);s.phase='flying';s.flight=0;s.flash=0;s.flips++;
    s.cake={x:200,y:303,a:0};beep(510,.04);
  },
  cancel(){},
  update(s,dt){
    if(s.resolved)return;
    s.flash=Math.max(0,s.flash-dt);
    if(s.phase==='ready'){
      s.clock=Math.min(3,s.clock+dt);
      if(s.clock>=3-1e-9)pancakeResolve(s,0,false);
    }
    else if(s.phase==='flying'){
      s.flight=Math.min(.80,s.flight+dt);
      const u=s.flight/.80;s.cake.y=303-139*Math.sin(Math.PI*u);s.cake.a=Math.PI*u;
      if(s.flight>=.80-1e-9){
        s.cake.y=303;s.cake.a=Math.PI;
        pancakeResolve(s,s.pending,true);
        if(s.resolved)return;
      }
    }
    score=Math.min(100,s.points);
  },
  timeout(s){s.resolved=true;s.phase='done';s.flash=0;score=Math.min(100,s.points);end('TIME UP')},
  draw(s){
    rect(0,0,400,440,'#d9d1b8');
    for(let x=0;x<=400;x+=50){line(x,0,x,302,'#b9bca5',1);for(let y=0;y<300;y+=42)line(x,y,x+50,y,'#c1c2aa',1)}
    rect(27,49,155,112,'#768c88',5);rect(34,56,141,97,grad(34,56,175,153,[[0,'#c9dfd8'],[1,'#88aaa3']]),2);line(104,56,104,153,'#f2e7ce',7);line(34,106,175,106,'#f2e7ce',6);
    rect(223,74,147,10,'#99754f');for(let x of[245,286,327]){line(x,82,x,123,'#6d705c',2);ellipse(x,143,13,20,'#a77746');ellipse(x-2,139,9,15,'#cb9c60')}
    rect(0,321,400,119,'#a9855e');for(let y=336;y<440;y+=23)line(0,y,400,y,'#886c4f',1);
    rect(68,336,264,66,'#c0b9a4',7);ellipse(200,361,53,18,'#5b5f56');
    for(let i=0;i<12;i++){const a=i*TAU/12;ellipse(200+Math.cos(a)*37,358+Math.sin(a)*10,3,8,'#75c5df',a)}
    rect(20,340,37,29,'#e4ba58',4);rect(21,340,35,9,'#ffe49a',3);mob(330,294,82,Math.sin(time*3)*.04);
    line(308,310,247,323,'#665e48',10);line(307,307,246,319,'#e4b58b',6);ellipse(200,330,55,11,'#433e3355');rect(237,312,57,10,'#654934',4);ellipse(200,318,49,13,'#313a3b');ellipse(200,313,48,11,'#677477');ellipse(200,311,43,8,'#202d31');
    const c=s.cake,ry=Math.max(2,Math.abs(Math.cos(c.a))*9);
    ellipse(c.x,c.y+3,24,ry,'#995833');ellipse(c.x,c.y,24,ry,Math.cos(c.a)<0?'#d99a4f':'#f2c776');
    for(let i=0;i<5;i++)ellipse(c.x-16+i*8,c.y+Math.sin(i*2)*ry*.4,2.5,Math.max(.6,ry*.2),'#ad713d');
    if(s.phase==='ready'){
      const value=pancakeMeter(s),now=Math.abs(value-.5)<=.12;
      rect(51,176,298,76,'#fff5dcf2',12);
      text(now?'今！ FLIP':'緑で FLIP',200,191,17,now?'#237449':'#6a5945');
      rect(69,212,262,15,'#c98265',7);rect(122,212,156,15,'#e9bc65',4);rect(169,210,62,19,now?'#32b477':'#77c89a',4);
      line(200,210,200,229,'#dbffde',1.5);
      const x=69+262*value;poly([[x-6,204],[x+6,204],[x,211]],'#304e50');line(x,214,x,229,'#233f45',3);
      text('早い',83,240,10,'#8b5c4c');text('緑 = 満点',200,240,11,'#326c46');text('遅い',317,240,10,'#8b5c4c');
      if(s.flash>0)text(s.lastLabel,200,276,17,s.lastLabel==='PERFECT!'?'#2d7d4f':'#a16e34');
    }
    for(let i=0;i<3;i++){const done=i<s.results.length;circle(168+i*32,386,11,done?'#f2c776':'#8d8e7c');if(done)text(Math.round(s.results[i]),168+i*32,386,10,'#654c30')}
    b7panel('MOB BREAKFAST / PANCAKE SERVICE',s.resolved?`${s.round} / 3 枚 完了`:s.phase==='flying'?'自動で裏返し → キャッチ':`${s.round+1} / 3 枚 · あと${Math.max(0,3-s.clock).toFixed(1)}秒`,'#574c3c');
  },
  summary:s=>`ボタン操作 ${s.flips}/3回。得点：${Array.from({length:3},(_,i)=>s.results[i]===undefined?'未操作':Math.round(s.results[i])+'点').join(' / ')}。`
});
