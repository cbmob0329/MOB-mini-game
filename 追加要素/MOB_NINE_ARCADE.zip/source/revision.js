// Requested revisions. Approved juice/rally physics remain in their original definitions.
const titles={meteor:'モブくんギャラクシー',archery:'モブくんのゆらゆらアーチェリー',juice:'モブくんのピッタリジュース',lock:'モブくんのくるくるロック',shield:'モブくんシールド360',rally:'モブくんラリー',inertial_docking:'モブくんの宇宙ドッキング',pendulum_cargo:'モブくんの吊り荷ピタッ',pancake_flip_catch:'モブくんのパンケーキ返し'};
defs.forEach((g,i)=>{g.title=titles[g.id]||g.title;g.number=g.number||i+1});
const gameById=id=>defs.find(g=>g.id===id);
gameById('lathe_pottery').seconds=10;
gameById('ballistic_firehose').seconds=10;
const meteorGame=gameById('meteor'),meteorUpdate=meteorGame.update,meteorFx=fx;
meteorGame.update=function(s,dt){const before=s.kills;this.originalUpdating=true;meteorUpdate.call(this,s,dt);this.originalUpdating=false;score=clamp(s.kills*5+s.got*2-s.hits*15,0,100)};
fx=function(x,y,label,c){if(meteorGame.originalUpdating)label=label==='+10'?'+5':label==='+5'?'+2':label==='HIT −10'?'HIT −15':label;meteorFx(x,y,label,c)};
meteorGame.rules='下部スティック＋FIRE。隕石＋5点、星くず＋2点、被弾−15点。12秒。';meteorGame.scoring='破壊×5＋星くず×2−被弾×15。0〜100点。';meteorGame.summary=s=>`破壊 ${s.kills}×5＋星 ${s.got}×2−被弾 ${s.hits}×15`;
const lockGame=gameById('lock'),lockUpdate=lockGame.update;
lockGame.update=function(s,dt){if(s.wait<=0&&s.round<10)s.a+=(2.65+s.round*.15)*.7*dt;lockUpdate.call(this,s,dt)};
const shieldGame=gameById('shield'),shieldUpdate=shieldGame.update;
shieldGame.update=function(s,dt){shieldUpdate.call(this,s,dt);for(const b of s.balls)if(!b.faster){b.speed*=1.6;b.faster=true}};

// Shared ship outline: the target and player use identical geometry and orientation.
function dockShape(x,y,color){ctx.save();ctx.translate(x,y);poly([[-25,-20],[-5,-12],[23,-8],[31,0],[23,8],[-5,12],[-25,20],[-18,0]],color);ellipse(0,0,14,11,'#314f71');ctx.restore()}
function dockAccuracy(s){return 100*clamp(1-Math.hypot(s.x-294,s.y-166)/40)}
const dockGame=gameById('inertial_docking'),dockInit=dockGame.init,dockDraw=dockGame.draw;
dockGame.init=()=>({...dockInit(),hold:0,obstacles:[{x:161,y:246,r:25},{x:223,y:113,r:22},{x:266,y:292,r:25}]});
dockGame.rules='岩を避け、同じ船型の輪郭を重ねよう。スティックを離して0.35秒静止すると接続確定。';dockGame.description='障害物を避けて、船型の位置をぴったり合わせよう。';dockGame.scoring='輪郭中心の位置誤差0pxで100点、40pxで0点。接続確定時に終了。';
dockGame.update=function(s,dt){if(s.resolved)return;const d=direction(),moving=Math.hypot(d.x,d.y)>.03;if(moving)s.active=true;s.thrustX=d.x;s.thrustY=d.y;s.vx=lerp(s.vx,d.x*180,1-Math.exp(-(moving?19:27)*dt));s.vy=lerp(s.vy,d.y*180,1-Math.exp(-(moving?19:27)*dt));s.x=clamp(s.x+s.vx*dt,28,340);s.y=clamp(s.y+s.vy*dt,52,386);for(const o of s.obstacles){let dx=s.x-o.x,dy=s.y-o.y,n=Math.hypot(dx,dy),r=o.r+23;if(n<r){s.x=o.x+(dx/(n||1)||1)*r;s.y=o.y+dy/(n||1)*r;s.vx=s.vy=0}}score=s.active?dockAccuracy(s):0;s.hold=s.active&&!moving&&Math.hypot(s.vx,s.vy)<4&&Math.hypot(s.x-294,s.y-166)<27?s.hold+dt:0;if(s.hold>=.35){s.locked=s.resolved=true;s.vx=s.vy=0;end('DOCKED')}};
dockGame.timeout=s=>{s.resolved=true;score=s.active?dockAccuracy(s):0;end('APPROACH COMPLETE')};
dockGame.draw=function(s){dockDraw(s);for(const o of s.obstacles)rock(o.x,o.y,o.r,time*.3);ctx.save();ctx.globalAlpha=.65;dockShape(294,166,'#83ffbe');ctx.restore();dockShape(s.x,s.y,'#e1e8e9');mob(s.x,s.y,26);rect(100,397,270,35,'#14213e');text(s.locked?`接続完了 ${Math.round(score)}点`:'輪郭を合わせ、離して静止で確定',235,416,12,'#d1ffe3')};dockGame.summary=s=>`船型の位置一致 ${Math.round(score)}点 / 中心誤差 ${Math.hypot(s.x-294,s.y-166).toFixed(1)}px`;

function cargoWave(t){return{x:Math.sin(t*2.1)*29,y:Math.sin(t*2.7)*15}}
const cargoGame=gameById('pendulum_cargo'),cargoInit=cargoGame.init,cargoDraw=cargoGame.draw;
cargoGame.init=()=>({...cargoInit(),seaTime:0});
cargoScore=function(s,p){const {left,right}=cargoFootprint(s,p),wave=cargoWave(s.seaTime);return 100*clamp((Math.min(right,337+wave.x)-Math.max(left,230+wave.x))/(right-left))};
cargoGame.update=function(s,dt){if(s.resolved||dt<=0)return;s.seaTime+=dt;let accel=0;if(!s.committed){const d=direction(),old=s.v;s.v=lerp(s.v,d.x*145,1-Math.exp(-13*dt));accel=(s.v-old)/dt;s.x=clamp(s.x+s.v*dt,48,352)}const lower=s.committed?143:0;s.len+=lower*dt;const wind=1.35*Math.sin(s.seaTime*2.3)+.65*Math.cos(s.seaTime*4.1);s.av+=(-520/s.len*Math.sin(s.a)-accel/s.len*.3-1.5*s.av+wind)*dt;s.a=clamp(s.a+s.av*dt,-.52,.52);let p=cargoPose(s),deck=351+cargoWave(s.seaTime).y;if(s.committed&&p.y+cargoBottom(s)>=deck){s.len=(deck-cargoBottom(s)-83)/Math.cos(s.a);p=cargoPose(s);s.last=cargoScore(s,p);s.placed={x:p.x,y:deck-cargoBottom(s),v:0};s.v=s.av=0;s.lower=false;s.landed=s.resolved=true;score=s.last;end('LANDING COMPLETE');return}score=0};
cargoGame.draw=function(s){cargoDraw(s);const wave=cargoWave(s.seaTime);rect(0,310,400,130,'#245e79');for(let i=0;i<10;i++)line(0,330+i*12,400,330+i*12+Math.sin(s.seaTime+i)*5,'#8cdae155',2);poly([[220+wave.x,351+wave.y],[347+wave.x,351+wave.y],[332+wave.x,383+wave.y],[235+wave.x,383+wave.y]],'#4a4647');rect(230+wave.x,351+wave.y,107,8,'#7ad9a0');const p=cargoPose(s);ctx.save();ctx.translate(p.x,p.y);ctx.rotate(s.a);rect(-38,-20,76,38,'#b95c49',3);text('MOB',0,0,12,'#fff2c9');ctx.restore();text('海上の台座 · 風と波を読んで1回だけ着地',200,418,11,'#e7fff0')};cargoGame.rules='左右で位置合わせ。強い横風と波で揺れる海上の台座へLOWERを1回。置いた瞬間に終了。';

const pancakeGame=gameById('pancake_flip_catch'),pancakeUpdate=pancakeGame.update,pancakeDraw=pancakeGame.draw;
pancakeAward=s=>(100/3)*clamp(1-Math.max(0,Math.abs(pancakeMeter(s)-.5)-.075)/.425);
pancakeGame.update=function(s,dt){const prior=s.phase;pancakeUpdate.call(this,s,dt);if(s.phase==='flying')s.cake.a=Math.PI*7*(s.flight/.8);if(prior==='flying'&&s.phase!=='flying')fx(200,300,s.lastLabel,'#ffd66f')};
pancakeGame.draw=function(s){pancakeDraw(s);if(s.phase==='ready'){rect(69,210,262,19,'#c98265',4);rect(180.35,210,39.3,19,'#32b477',4);const x=69+262*pancakeMeter(s);line(x,207,x,232,'#203e45',3);text(Math.abs(pancakeMeter(s)-.5)<=.075?'今！ FLIP':'中央の緑で FLIP',200,191,17,'#237449')}if(s.phase==='flying'){const u=s.flight/.8;ctx.save();ctx.translate(200,s.cake.y);ctx.rotate(s.cake.a);ellipse(0,0,34,11,'#ffdb84');ellipse(0,-3,28,8,'#d58b38');ctx.restore();for(let i=0;i<16;i++){let a=i*TAU/16+u*8;line(200+Math.cos(a)*48,s.cake.y+Math.sin(a)*30,200+Math.cos(a)*75,s.cake.y+Math.sin(a)*55,'#fff1b9aa',2)}text('SPIN × 3.5',200,90,25,'#7f4a26')}};
pancakeGame.scoring='中央±7.5%で1枚33⅓点。外れるほど減点。3枚で100点。';

// Power is locked before each throw. Each monster consumes exactly one penetration.
function discPower(v){return clamp(1-Math.abs(v-.5)*2)}
function discPercent(power){return Math.floor(power*1000+1e-9)/10}
function discPierces(power){return power>=.9-1e-12?2:power>=.85-1e-12?1:0}
function discMonsters(t){return[{id:0,x:200+Math.sin(t*5.6)*143,y:244,r:24},{id:1,x:200+Math.sin(t*6.3+1.8)*143,y:155,r:24}]}
function discContact(d,m){if(d.hitIds.includes(m.id))return false;d.hitIds.push(m.id);if(d.pierces>0){d.pierces--;return false}return true}
const discGame=gameById('curved_disc'),discInit=discGame.init,discInput=discGame.input,discUpdate=discGame.update,discDraw=discGame.draw;
discGame.init=()=>({...discInit(),power:null,powerPhase:0,powerLeft:3,monsterTime:0});
discGame.input=function(s,e){if(s.finished)return;if(s.wait>0){if(e.kind==='buttonUp'||e.kind==='buttonCancel')s.throwHeld=false;return}if(s.power===null&&e.kind==='buttonDown'&&e.action==='throw'&&!s.throwHeld){s.throwHeld=true;s.power=discPower(b13Meter({phase:s.powerPhase}));s.feedback=`POWER ${discPercent(s.power)}%`;return}discInput.call(this,s,e);if(s.disc&&s.disc.pierces===undefined){s.disc.pierces=discPierces(s.power);s.disc.hitIds=[]}};
discGame.update=function(s,dt){if(s.finished)return;s.monsterTime+=dt;if(s.power===null&&!s.disc&&s.wait<=0){s.powerPhase+=dt*.85;s.powerLeft=Math.max(0,s.powerLeft-dt);if(s.powerLeft===0){b13Resolve(s,0,true);s.powerLeft=3}return}const round=s.round,disc=s.disc;discUpdate.call(this,s,dt);if(disc&&s.disc){for(const m of discMonsters(s.monsterTime))if(Math.hypot(disc.x-m.x,disc.y-m.y)<m.r+13){if(discContact(disc,m)){b13Resolve(s,0);break}else fx(m.x,m.y,'貫通','#ffec8b')}}if(s.round!==round){s.power=null;s.powerPhase=0;s.powerLeft=3}};
discGame.draw=function(s){discDraw(s);for(const m of discMonsters(s.monsterTime)){circle(m.x,m.y,m.r,'#9a4a79');poly([[m.x-20,m.y-12],[m.x-16,m.y-36],[m.x-4,m.y-20]],'#d388ad');poly([[m.x+20,m.y-12],[m.x+16,m.y-36],[m.x+4,m.y-20]],'#d388ad');circle(m.x-8,m.y-3,6,'#fff7cb');circle(m.x+8,m.y-3,6,'#fff7cb');circle(m.x-8,m.y-3,2,'#352541');circle(m.x+8,m.y-3,2,'#352541')}if(s.power===null&&!s.disc&&s.wait<=0){rect(45,289,310,65,'#315e59');const v=b13Meter({phase:s.powerPhase});text('最初に POWER を止める',200,303,13,'#fff4d0');rect(68,319,264,15,'#92795c',4);rect(180.2,317,39.6,19,'#d9b658',3);rect(186.8,317,26.4,19,'#8be5a4',3);line(68+v*264,314,68+v*264,339,'#fff',3);text(`${discPercent(discPower(v))}% · 85%=1体 / 90%=2体`,200,345,10,'#fff4d0')}else text(`POWER ${discPercent(s.power||0)}% · 残り貫通 ${s.disc?s.disc.pierces:discPierces(s.power||0)}`,200,278,12,'#234e48')};
discGame.rules='最初のTHROWでパワー確定、次のTHROWで投げる。左右に高速移動するモンスター2体に注意。';discGame.controlHint='最初にパワー、次に投げるタイミング';discGame.description='パワーを合わせて高速移動モンスターを貫通しよう。';discGame.scoring='一致率85%以上で1体、90%以上で2体貫通。衝突して貫通が残っていなければ0点。3投最大100点。';
